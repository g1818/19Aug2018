package com.gs.crick.dto;

import java.util.Date;

public class FeedBackDTO {

	private 	int feedbackId;
	private 	String userEmail;
	private 	String feedbackSub;
	private 	String feedbackDesc;
	private 	Date createDate;
	public int getFeedbackId() {
		return feedbackId;
	}
	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getFeedbackSub() {
		return feedbackSub;
	}
	public void setFeedbackSub(String feedbackSub) {
		this.feedbackSub = feedbackSub;
	}
	public String getFeedbackDesc() {
		return feedbackDesc;
	}
	public void setFeedbackDesc(String feedbackDesc) {
		this.feedbackDesc = feedbackDesc;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	
}
