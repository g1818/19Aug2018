package com.gs.crick.dto;

/**
 * @author Guna.Sekhar
 *
 */
public class PlayersDTO {
	

	
	private 	String  playerid;
	private 	String playername;
	private 	String country;
	private 	String image;
	
	
	public String getPlayerid() {
		return playerid;
	}
	public void setPlayerid(String playerid) {
		this.playerid = playerid;
	}
	public String getPlayername() {
		return playername;
	}
	public void setPlayername(String playername) {
		this.playername = playername;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	
	
	

}
