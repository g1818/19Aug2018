package com.gs.crick.dto;

public class RankDTO {
	
	private 	String  ranknumber;
	private 	String playerName;
	private 	String countryName;
	public String getRanknumber() {
		return ranknumber;
	}
	public void setRanknumber(String ranknumber) {
		this.ranknumber = ranknumber;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	

	
	

}
