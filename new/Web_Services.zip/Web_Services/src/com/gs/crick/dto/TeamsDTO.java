package com.gs.crick.dto;

public class TeamsDTO {
	
	
	private 	String  teamid;
	private 	String teamname;
	private 	String teamshname;
	private 	String teamimage;
	
	
	
	public String getTeamid() {
		return teamid;
	}
	public void setTeamid(String teamid) {
		this.teamid = teamid;
	}
	public String getTeamname() {
		return teamname;
	}
	public void setTeamname(String teamname) {
		this.teamname = teamname;
	}
	public String getTeamshname() {
		return teamshname;
	}
	public void setTeamshname(String teamshname) {
		this.teamshname = teamshname;
	}
	public String getTeamimage() {
		return teamimage;
	}
	public void setTeamimage(String teamimage) {
		this.teamimage = teamimage;
	}
	

}
