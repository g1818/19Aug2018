package com.gs.crick.dto;

/**
 * Created by Guna Sekhar on 26-06-2018.
 */

public class MatchArgumentsDTO  {


	
    private 	String matchArgumentId;
    private 	String argumentDesc;
    private     String argumentValue;
    private     String matcheid;
    
    
	public String getMatchArgumentId() {
		return matchArgumentId;
	}
	public void setMatchArgumentId(String matchArgumentId) {
		this.matchArgumentId = matchArgumentId;
	}
	public String getArgumentDesc() {
		return argumentDesc;
	}
	public void setArgumentDesc(String argumentDesc) {
		this.argumentDesc = argumentDesc;
	}
	public String getArgumentValue() {
		return argumentValue;
	}
	public void setArgumentValue(String argumentValue) {
		this.argumentValue = argumentValue;
	}
	public String getMatcheid() {
		return matcheid;
	}
	public void setMatcheid(String matcheid) {
		this.matcheid = matcheid;
	}
    
    
	
    

  
}
