package com.gs.crick.dto;

public class MailDataDTO {

	private 	String subject;
	private 	String body;
	private 	String regards;
	private 	String tomail;
	
	
	
	public String getTomail() {
		return tomail;
	}
	public void setTomail(String tomail) {
		this.tomail = tomail;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getRegards() {
		return regards;
	}
	public void setRegards(String regards) {
		this.regards = regards;
	}
}
