package com.gs.crick.useroperations;

import java.io.StringReader;
import java.lang.reflect.Type;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.gs.crick.dto.MailDataDTO;
import com.gs.crick.dto.UserDetailsDTO;
import com.gs.crick.service.IUser;
@Component
@Path("/userCreation")
public class UserRegistration {

	@Autowired
	private IUser userervice;

	@GET
	@Path("/doRegistration")
	@Produces(MediaType.APPLICATION_JSON)
	public String printMessage(@QueryParam("userName") String userName, @QueryParam("password") String password,
			@QueryParam("phone_no") String phone_no, @QueryParam("email") String email) {
		System.out.println("Registration Details:::" + userName + "::" + password + "::" + phone_no + "::" + email);
		UserDetailsDTO user = new UserDetailsDTO();
		UserDetailsDTO jsonUser = new UserDetailsDTO();
		jsonUser.setUserName(userName);
		jsonUser.setEmail_id(email);
		jsonUser.setPhone_number(phone_no);
		if (!validateUserCredentials(email)) {
			user.setUserName(userName);
			user.setPassword(password);
			user.setEmail_id(email);
			user.setPhone_number(phone_no);
			userervice.doSaveUserDetails(user);
			jsonUser.setStatus(true);
		} else {

			jsonUser.setStatus(false);

		}
		return constructJSON(jsonUser);

	}


private boolean validateUserCredentials(String email) {
	System.out.println("validateUserCredentials::Start::"+email);
	return userervice.doCheckDuplicateUserID(email);
}

@POST
@Path("/forgotPassword")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public String doSendForgotPAss(String json) {
	String user_Email = null;
	boolean Sendmail = false;
	try (JsonReader reader = Json.createReader(new StringReader(json))) {
		JsonObject object = reader.readObject();
		user_Email = object.getString("EMAIL");
		String value = userervice.getpassword(user_Email);
		if (value.isEmpty()) {
			MailDataDTO mail = new MailDataDTO();
			mail.setTomail(user_Email);
			mail.setSubject("Your Password to Acess CRICKPICO");
			mail.setBody("Please use the password to access the CRICKPICO\n\n" + " Thank you,\n" + " CRICKPICO\n"
					+ "  Ph:+91-8919411154");
			Sendmail = userervice.SendMail(mail);

		}
	} catch (Exception e) {
		e.printStackTrace();
	}
	System.out.println("Status"+Sendmail);
	return String.valueOf(Sendmail);
}	


@GET
@Path("/login")
@Produces(MediaType.APPLICATION_JSON)
public String login(@QueryParam("email") String email, @QueryParam("password") String password) {

	UserDetailsDTO userDetailsDTO = new UserDetailsDTO();

	userDetailsDTO = userervice.getUserInfoBasedOnUserName(email);
	if (userDetailsDTO == null) {
		userDetailsDTO = new UserDetailsDTO();
		userDetailsDTO.setStatus(false);

	} else {
		boolean verifyPassword = userervice.doGetpass(email, password);
		userDetailsDTO.setStatus(verifyPassword);
		userDetailsDTO.setSaltValue(null);
		userDetailsDTO.setUser_id(null);
		userDetailsDTO.setPassword(null);
	}

	return constructJSON(userDetailsDTO);

}

public static String constructJSON(UserDetailsDTO user) {
	if(user != null){
		
		Gson gson = new Gson();
		Type type = new TypeToken<UserDetailsDTO>() {
		}.getType();
		return gson.toJson(user, type);
		}
		return null;
	}

	
}

