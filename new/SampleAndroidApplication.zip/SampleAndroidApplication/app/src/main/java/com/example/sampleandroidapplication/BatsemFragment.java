package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class BatsemFragment   extends FragmentStatePagerAdapter
{

    List<String> rankingTabName=new ArrayList<>();
    int id;
    public BatsemFragment(FragmentManager fm, List<String> rankingTabName,int id){

        super(fm);
        this.rankingTabName=rankingTabName;
        this.id=id;
    }


    @Override
    public Fragment getItem(int position) {
        TESTFragmentBatsmen tab1=new TESTFragmentBatsmen();
        int tabId=0;
        Bundle bundle=new Bundle();
        if(rankingTabName.get(position).equalsIgnoreCase("test")){

              tabId=1;
        }
        else if(rankingTabName.get(position).equalsIgnoreCase("odi")){

                   tabId=2;
        }
        else if(rankingTabName.get(position).equalsIgnoreCase("t20")){

                    tabId=3;
        }
        bundle.putInt("mainTabId",id);
        bundle.putInt("innerTabId",tabId);
        tab1.setArguments(bundle);
        return  tab1;
    }

    @Override
    public int getCount() {
        return rankingTabName.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        if (rankingTabName != null) {
            return rankingTabName.get(position);
        }
        return null;
    }

}
