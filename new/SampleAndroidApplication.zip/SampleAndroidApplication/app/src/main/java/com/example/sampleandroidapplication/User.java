package com.example.sampleandroidapplication;

/**
 * Created by Ashwini.R on 30-05-2018.
 */

public class User {


    String name;
    String matchName;
    String score;
    String matchName1;
    String score1;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMatchName() {
        return matchName;
    }

    public void setMatchName(String matchName) {
        this.matchName = matchName;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getMatchName1() {
        return matchName1;
    }

    public void setMatchName1(String matchName1) {
        this.matchName1 = matchName1;
    }

    public String getScore1() {
        return score1;
    }

    public void setScore1(String score1) {
        this.score1 = score1;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    String comments;
}
