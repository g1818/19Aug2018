package com.example.sampleandroidapplication;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.TableRow;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.RankDTO;

import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class TestBatsmenArrayAdaopter  extends ArrayAdapter<RankDTO> {

    Context context;
    List<RankDTO> user;


    public TestBatsmenArrayAdaopter(Context context, List<RankDTO> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }
    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.test__batsmen_listview, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label1);
        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        TextView textView3 = (TextView) rowView.findViewById(R.id.label3);
        textView.setText(user.get(position).getRanknumber());
        textView2.setText(user.get(position).getPlayerName());
        textView3.setText(user.get(position).getCountryName());
        TableRow.LayoutParams lc$param = new TableRow.LayoutParams();
        lc$param.height = GridLayout.LayoutParams.WRAP_CONTENT;
        lc$param.width = dpToPx(120);

        TableRow.LayoutParams lc$params = new TableRow.LayoutParams();
        lc$params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        lc$params.width = dpToPx(200);


        textView3.setLayoutParams(lc$param);
        textView.setLayoutParams(lc$param);
        textView2.setLayoutParams(lc$params);
        /*else{
            textView2.setCompoundDrawablesWithIntrinsicBounds(R.drawable.live_help, 0, 0, 0);
        }*/

        return rowView;
    }

}