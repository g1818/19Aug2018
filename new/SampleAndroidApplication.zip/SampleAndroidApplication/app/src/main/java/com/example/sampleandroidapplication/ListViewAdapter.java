package com.example.sampleandroidapplication;

import android.content.Context;
import android.database.DataSetObserver;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Ashwini.R on 30-05-2018.
 */

public class ListViewAdapter extends ArrayAdapter<User> {

    Context context;
    List<User> user;


    public ListViewAdapter(Context context, List<User> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.activity_listview_tab, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label);
        textView.setText(user.get(position).getName());
        TextView textView1 = (TextView) rowView.findViewById(R.id.label1);
        textView1.setText(user.get(position).getMatchName());
        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        textView2.setText(user.get(position).getScore());
        TextView textView3 = (TextView) rowView.findViewById(R.id.label3);
        textView3.setText(user.get(position).getMatchName1());

        return rowView;
    }

}