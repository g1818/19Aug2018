package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class MostRuns  extends Fragment {

    View v;
    ViewPager viewPager;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.most_runs, null);
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        List<Batsmen> batsmen=new ArrayList<>();
        Batsmen batsmen1=new Batsmen();
        batsmen1.setName("Batsmen");
        batsmen1.setM("M");
        batsmen1.setI("I");
        batsmen1.setR("R");
        batsmen1.setAvg("Avg");
        batsmen.add(batsmen1);
        Batsmen batsmen2=new Batsmen();
        batsmen2.setName("Ash");
        batsmen2.setM("2");
        batsmen2.setI("3");
        batsmen2.setR("4");
        batsmen2.setAvg("55");
        batsmen.add(batsmen2);
        batsmen.add(batsmen2);


        ListView listView = (ListView)v.findViewById(R.id.tabList);

        MostRunsArrayAdaopter mostRunsArrayAdaopter=new MostRunsArrayAdaopter(v.getContext(),batsmen);

        listView.setAdapter(mostRunsArrayAdaopter);


        return v;


    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }

}


