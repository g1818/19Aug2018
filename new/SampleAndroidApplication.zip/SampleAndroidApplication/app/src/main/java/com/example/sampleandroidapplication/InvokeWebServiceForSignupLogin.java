package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import com.example.sampleandroidapplication.com.dtos.UserDetailsDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

import static android.content.Context.MODE_PRIVATE;

/**
 * Created by Ashwini.R on 11-06-2018.
 */

public class InvokeWebServiceForSignupLogin extends AsyncTask<String,Void,String> {

    Context context;
    AppCompatActivity mainActivity;
    int id;
    String password;

    public InvokeWebServiceForSignupLogin(Context context,AppCompatActivity mainActivity,int id,String password) {
        this.context = context;
        this.mainActivity=mainActivity;
        this.id=id;
        this.password=password;
    }

    @Override
    protected String doInBackground(String... strings) {
        StringBuffer buffer = new StringBuffer();
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String line = "";
            while ((line = bf.readLine()) != null) {
                buffer.append(line);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return buffer.toString();
    }

    @Override

    public void onPostExecute(String string) {
        ObjectMapper mapperObject = new ObjectMapper();
        try {
            UserDetailsDTO user = mapperObject.readValue(string, UserDetailsDTO.class);
            if(user != null){

                if(user.getStatus()){

                    SharedPreferences settings1 = context.getSharedPreferences(LoginCheck.Login_check, 0); // 0 - for private mode
                    SharedPreferences.Editor editors= settings1.edit();
                    editors.putBoolean("hasLoggedIn", false);
                    editors.commit();
                       SharedPreferences.Editor editor = context.getSharedPreferences("MY_PREFS_NAME", MODE_PRIVATE).edit();
                        editor.putString("username", user.getEmail_id());
                        editor.putString("password", password);
                        editor.putString("name", user.getUserName());
                        editor.apply();

                        Intent intent = new Intent(context, PinActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        FragmentManager fragmentManager = mainActivity.getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        mainActivity.startActivity(intent);
                        mainActivity.finish();




                }
                else{

                    if(id==1) {
                        Toast.makeText(mainActivity, "User already exisits!!!try to setpin", Toast.LENGTH_LONG).show();
                        /*new SendMail(mainActivity, "ashwinirs1996@gmail.com", "Test", "ashwini").execute().get();*/
                    }
                    else
                        Toast.makeText(mainActivity, "Incorrect Credentials!!", Toast.LENGTH_LONG).show();

                }

            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

