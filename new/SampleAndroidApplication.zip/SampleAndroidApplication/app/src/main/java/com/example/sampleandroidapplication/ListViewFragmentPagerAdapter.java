package com.example.sampleandroidapplication;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.SparseArray;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 30-05-2018.
 */

public class ListViewFragmentPagerAdapter  extends FragmentStatePagerAdapter {
    List<String> menus = new ArrayList<>();
    SparseArray<Fragment> registeredFragments = new SparseArray<Fragment>();


    public ListViewFragmentPagerAdapter(FragmentManager fm, List<String> men) {
        super(fm);
        menus = men;

    }

    @Override
    public int getCount() {
        if (menus != null) {
            return menus.size();
        }
        return 0;
    }


    @Override
    public Fragment getItem(int position) {
        return new Tab1();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        if (menus != null) {
            return menus.get(position);
        }
        return null;
    }


    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        Fragment fragment = (Fragment) super.instantiateItem(container, position);
        registeredFragments.put(position, fragment);
        return fragment;
    }

    /**
     * Remove the saved reference from our Map on the Fragment destroy
     *
     * @param container
     * @param position
     * @param object
     */
    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        registeredFragments.remove(position);
        super.destroyItem(container, position, object);
    }


    /**
     * Get the Fragment by position
     *
     * @param position tab position of the fragment
     * @return
     */
    public Fragment getRegisteredFragment(int position) {
        return registeredFragments.get(position);


    }
}