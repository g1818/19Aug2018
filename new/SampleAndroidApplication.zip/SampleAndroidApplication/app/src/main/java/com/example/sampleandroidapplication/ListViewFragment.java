package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTabHost;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 30-05-2018.
 */

public class ListViewFragment extends Fragment {

    private FragmentTabHost mTabHost;
    ListViewFragmentPagerAdapter adapterViewPager;  ViewPager viewPager;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_layout, null);
        viewPager = (ViewPager) v.findViewById(R.id.viewpager);
        TabLayout sliding_tabs = (TabLayout) v.findViewById(R.id.sliding_tabs);
        List<String> tabNames =new ArrayList<>();
        tabNames.add("LIVE");
        tabNames.add("UPCOMING");
        tabNames.add("RECENT");

        adapterViewPager = new ListViewFragmentPagerAdapter(getChildFragmentManager(), tabNames);
        viewPager.setAdapter(adapterViewPager);
        sliding_tabs.setupWithViewPager(viewPager);
        return v;
    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }

}
