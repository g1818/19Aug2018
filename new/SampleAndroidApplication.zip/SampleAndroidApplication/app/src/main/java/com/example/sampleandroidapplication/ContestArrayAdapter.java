package com.example.sampleandroidapplication;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.sampleandroidapplication.Payment;
import com.example.sampleandroidapplication.R;
import com.example.sampleandroidapplication.com.dtos.ContestDTO;
import com.example.sampleandroidapplication.com.dtos.MatchesDTO;
import com.example.sampleandroidapplication.com.dtos.QuestionAnswerPayment;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Guna.Sekhar on 6/14/2018.
 */

public class ContestArrayAdapter extends ArrayAdapter<ContestDTO> {

    Context context;
    List<ContestDTO> user;
    List<QuestionAnswerPayment> questionAnswerPaymentList;
    AppCompatButton appCompatButton;
    FragmentActivity fragmentActivity; TextView textView3;

    public ContestArrayAdapter(Context context, List<ContestDTO> values, List<QuestionAnswerPayment> questionAnswerPaymentList, FragmentActivity fragmentActivity) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
        this.questionAnswerPaymentList=questionAnswerPaymentList;
        this.fragmentActivity=fragmentActivity;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.contest_listview, parent, false);

        appCompatButton=(AppCompatButton)rowView.findViewById(R.id.button);

        TextView textView1 = (TextView) rowView.findViewById(R.id.label1);
        textView1.setText(user.get(position).getContestName());


        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        textView2.setText(String.valueOf(user.get(position).getContestWinerCount()));


        textView3 = (TextView) rowView.findViewById(R.id.label3);
        textView3.setText(user.get(position).getContestFee());

        TextView textView4 = (TextView) rowView.findViewById(R.id.label4);


        TextView textView5 = (TextView) rowView.findViewById(R.id.label5);
        textView5.setText(String.valueOf(user.get(position).getContestMaxEntryies()));

        if(user.get(position).getEntryiesLeft()>0){
            appCompatButton.setVisibility(View.VISIBLE);
            textView4.setText("Only "+user.get(position).getEntryiesLeft()+" spot left");
        }
        else{
            appCompatButton.setVisibility(View.GONE);
            textView4.setText("we don't have any more spots available");
        }

        appCompatButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                for(QuestionAnswerPayment questionAnswerPayment:questionAnswerPaymentList){

                    questionAnswerPayment.setContestId(user.get(position).getContestId());
                }

                Log.i("Selected Contest ",user.get(position).getContestId());
                Bundle bundle=new Bundle();
                bundle.putParcelableArrayList("questionList", (ArrayList<? extends Parcelable>) questionAnswerPaymentList);
                Log.i("amt",user.get(position).getContestFee());
                bundle.putString("amount",user.get(position).getContestFee());
                FragmentManager fragmentManager = fragmentActivity.getSupportFragmentManager();
                Payment payment=new Payment();
                payment.setArguments(bundle);
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, payment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();


            }
        });



        return rowView;
    }

}