package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.pinlockview.PinLockView;
import com.example.sampleandroidapplication.com.dtos.QuestionAnswerPayment;
import com.example.sampleandroidapplication.com.dtos.QuestionsDTO;
import com.example.sampleandroidapplication.com.dtos.SeriesDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.ads.AdView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Created by Ashwini.R on 21-06-2018.
 */

public class QuestionAnswersFragment extends Fragment {

    View v;
    PinLockView mPinLockView;
    private AdView mAdView;
    static int i = 0;
    String matchId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.questionanswers, null);
        Bundle args = getArguments();
        if(args != null){
            matchId = args.getString("matchId");
        }
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        String url=getString(R.string.ip_address).concat(getString(R.string.questions).concat(matchId));

        Log.i("url",url);
        new InvokeWebServiceForQuestionsAndAnswers(v,getActivity(),matchId).execute(url);


        return v;

    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}
class InvokeWebServiceForQuestionsAndAnswers extends AsyncTask<String,Void,String> {

    List<QuestionsDTO> questionsList;
    List<QuestionAnswerPayment> questionAnswerPaymentList=new ArrayList<>();
    View view;
    TextView tv1,timer;
    LinearLayout questionAnserlayout;
    RadioButton a, b;
    Button bt;
    RadioGroup rg;
    QuestionsDTO questionsDTO;
    String machId;
    QuestionAnswerPayment questionAnswerPayment;
    Button back;
    LinearLayout linearLayout;
    private ProgressDialog progressDialog;
    FragmentActivity fragmentActivity;
    InvokeWebServiceForQuestionsAndAnswers(View v, FragmentActivity fragmentActivity,String matchId) {
        view = v;
        this.fragmentActivity=fragmentActivity;
        this.machId=matchId;

    }

    @Override
    protected void onPreExecute() {

        progressDialog = ProgressDialog.show(view.getContext(), "Loading", "Please wait a moment!");
    }

    @Override
    protected String doInBackground(String... strings) {

        StringBuffer buffer = new StringBuffer();
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line = "";
            while ((line = bf.readLine()) != null) {
                buffer.append(line);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return buffer.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        linearLayout=(LinearLayout)view.findViewById(R.id.emptydata);
        linearLayout.setVisibility(View.GONE);
        questionAnserlayout=(LinearLayout)view.findViewById(R.id.fragment_container);
        RadioGroup radioGroup=(RadioGroup) view.findViewById(R.id.optionGroup);
        radioGroup.clearCheck();
        try {
            if (progressDialog.isShowing()) progressDialog.dismiss();
            ObjectMapper mapperObject = new ObjectMapper();

            Log.i("res",s);
            questionsList = mapperObject.readValue(s, mapperObject.getTypeFactory().constructCollectionType(List.class, QuestionsDTO.class));
            System.out.println("inside postexecute=" + questionsList.size());

            if (questionsList != null && !questionsList.isEmpty()) {
                questionAnserlayout.setVisibility(View.VISIBLE);
                Collections.shuffle(questionsList);
                for(int i=0;i<10;i++){
                    QuestionAnswerPayment questionAnswerPayment=new QuestionAnswerPayment();
                    questionAnswerPayment.setMatchQuestionsID(questionsList.get(i).getMatchQuestionsID());
                    questionAnswerPayment.setMatchId(machId);
                    questionAnswerPayment.setQuestionID(questionsList.get(i).getQuestionsID());
                    questionAnswerPaymentList.add(questionAnswerPayment);

                }
                 QuestionAnswersFragment.i=0;
             /*   timer = (TextView) view.findViewById(R.id.timer);*/
                tv1 = (TextView) view.findViewById(R.id.ques);
                rg = (RadioGroup)view. findViewById(R.id.optionGroup);
                a = (RadioButton) view.findViewById(R.id.option1);
                b = (RadioButton) view.findViewById(R.id.option2);

                bt = (Button) view.findViewById(R.id.next);
                back = (Button) view.findViewById(R.id.back);
                back.setVisibility(View.GONE);
             /*   CountDownTimer countDownTimer = new CountDownTimer(900000, 1000) {

                    @Override
                    public void onTick(long millisUntilFinished) {
                        String text = String.format(Locale.getDefault(), "Time Remaining %02d min: %02d sec",
                                TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) % 60,
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) % 60);

                        timer.setText(text);
                    }*//*

                    @Override
                    public void onFinish() {

                        timer.setText("done");

                    }
                };
                countDownTimer.start();*/
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if(bt.getText().toString().equalsIgnoreCase("Submit")){
                            int radioButtonID = rg.getCheckedRadioButtonId();
                            if (radioButtonID == -1) {
                                Toast.makeText(view.getContext(), "Please select answer ", Toast.LENGTH_LONG).show();
                                return;
                            }
                            else{
                                RadioButton radioButton = (RadioButton)
                                        rg.findViewById(radioButtonID);
                                String selectedtext = (String) radioButton.getText();
                                questionsDTO.setAnswers(selectedtext);
                                questionAnswerPayment.setAnswers(selectedtext);

                            }
                            for(QuestionAnswerPayment questionAnswerPayment1:questionAnswerPaymentList){

                                Log.i("User Info",questionAnswerPayment1.getMatchQuestionsID()+questionAnswerPayment1.getAnswers());
                            }
                            Bundle bundle=new Bundle();
                            bundle.putString("machId",machId);
                            bundle.putParcelableArrayList("questionList", (ArrayList<? extends Parcelable>) questionAnswerPaymentList);
                            FragmentManager fragmentManager = fragmentActivity.getSupportFragmentManager();
                            JoinConstest joinConstest=new JoinConstest();
                            joinConstest.setArguments(bundle);
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            fragmentTransaction.replace(R.id.fragment_container, joinConstest);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();
                        }
                        int radioButtonID = rg.getCheckedRadioButtonId();
                        Log.i("id", String.valueOf(radioButtonID));
                        if (radioButtonID == -1) {
                            Toast.makeText(view.getContext(), "Please select answer ", Toast.LENGTH_LONG).show();
                            return;
                        }
                        RadioButton radioButton = (RadioButton)
                                rg.findViewById(radioButtonID);
                        String selectedtext = (String) radioButton.getText();
                        questionsDTO.setAnswers(selectedtext);
                        questionAnswerPayment.setAnswers(selectedtext);


                        if ((QuestionAnswersFragment.i < 10)) {
                            bt.setText("Next");
                            rg.clearCheck();
                            QuestionAnswersFragment.i++;
                            if(QuestionAnswersFragment.i==10){
                            /*    bt.setText("Submit");
                                Toast.makeText(view.getContext(), "Finished", Toast.LENGTH_LONG).show();*/
                            return;
                            }
                            else if(QuestionAnswersFragment.i==9) { bt.setText("Submit"); dogetQuestionsAndAnswers();  }
                            else {
                                dogetQuestionsAndAnswers();
                            }
                        }


                        if(QuestionAnswersFragment.i == 0){
                            back.setVisibility(View.GONE);
                        }
                        else{
                            back.setVisibility(View.VISIBLE);
                        }
                    }
                });
                back.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {



                        int radioButtonID = rg.getCheckedRadioButtonId();
                        Log.i("id", String.valueOf(radioButtonID));
                        if (radioButtonID == -1) {
                            bt.setText("Next");
                        }
                        else {
                            bt.setText("Next");
                            RadioButton radioButton = (RadioButton)
                                    rg.findViewById(radioButtonID);
                            String selectedtext = (String) radioButton.getText();
                            questionsDTO.setAnswers(selectedtext);
                            questionAnswerPayment.setAnswers(selectedtext);
                        }

                        if (QuestionAnswersFragment.i >= 0) {
                            rg.clearCheck();
                            QuestionAnswersFragment.i--;
                            dogetQuestionsAndAnswers();
                        }
                        if (QuestionAnswersFragment.i == 0) {
                            back.setVisibility(View.GONE);
                        }
                        else{
                            back.setVisibility(View.VISIBLE);
                        }

                        return;


                    }
                });
                dogetQuestionsAndAnswers();





            }
            else{
                questionAnserlayout.setVisibility(View.GONE);
                linearLayout.setVisibility(View.VISIBLE);
                return;
            }
        } catch (Exception e) {

            e.printStackTrace();
        }

    }
    public void dogetQuestionsAndAnswers() {

        questionsDTO = questionsList.get(QuestionAnswersFragment.i);
        questionAnswerPayment=questionAnswerPaymentList.get(QuestionAnswersFragment.i);
        tv1.setText(String.valueOf(QuestionAnswersFragment.i+1)+". " +questionsDTO.getQuestionDesc());
        a.setText(questionsDTO.getFirstOption());
        b.setText(questionsDTO.getSecondOption());


        if (questionsDTO.getAnswers() != null) {
            if (questionsDTO.getFirstOption().equalsIgnoreCase(questionsDTO.getAnswers()))
                a.setChecked(true);
            else if (questionsDTO.getSecondOption().equalsIgnoreCase(questionsDTO.getAnswers()))

                b.setChecked(true);



        }

    }
}


