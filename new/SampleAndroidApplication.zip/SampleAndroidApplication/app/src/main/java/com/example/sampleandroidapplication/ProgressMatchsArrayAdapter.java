package com.example.sampleandroidapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.MatchesDTO;

import java.util.List;

/**
 * Created by Ashwini.R on 31-05-2018.
 */

public class ProgressMatchsArrayAdapter extends ArrayAdapter<MatchesDTO> {

    Context context;
    List<MatchesDTO> matchesDTO;


    public ProgressMatchsArrayAdapter(Context context, List<MatchesDTO> values) {
        super(context, -1, values);
        this.context = context;
        this.matchesDTO = values;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.activity_listview_homepage_tab, parent, false);



        TextView textView = (TextView) rowView.findViewById(R.id.label1);
        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        TextView textView3 = (TextView) rowView.findViewById(R.id.label3);
        TextView textView4 = (TextView) rowView.findViewById(R.id.label4);
        TextView textView5 = (TextView) rowView.findViewById(R.id.label5);
        TextView textView6 = (TextView) rowView.findViewById(R.id.label6);


        textView.setText(matchesDTO.get(position).getMatchcomment()+" In "+matchesDTO.get(position).getVenue());
        textView2.setText(matchesDTO.get(position).getFirstTeam());
        textView3.setText(matchesDTO.get(position).getFirstteamscore());
        textView4.setText(matchesDTO.get(position).getSecondTeam());
        textView5.setText(matchesDTO.get(position).getSecondteamscore());
        textView6.setText("");


        return rowView;
    }

}
