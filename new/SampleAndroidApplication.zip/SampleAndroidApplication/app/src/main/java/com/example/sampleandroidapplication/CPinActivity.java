package com.example.sampleandroidapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.andrognito.pinlockview.IndicatorDots;
import com.andrognito.pinlockview.PinLockListener;
import com.andrognito.pinlockview.PinLockView;

public class CPinActivity extends AppCompatActivity {
    PinLockView mPinLockView;
    Boolean pinFlag=false;
    SharedPreferences.Editor editors;
    String pins;
    String setPin;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cpin);
        mPinLockView = (PinLockView) findViewById(R.id.pin_lock_view);
        SharedPreferences settings = getSharedPreferences("MY_PREFS_NAME", 0);
         setPin  = settings.getString("pin","defaultStringIfNothingFound");
        SharedPreferences settings1 = this.getSharedPreferences(LoginCheck.Login_check, 0); // 0 - for private mode
        editors= settings1.edit();


        mPinLockView = (PinLockView) findViewById(R.id.pin_lock_view);
        PinLockListener mPinLockListener = new PinLockListener() {
            @Override
            public void onComplete(String pin) {
                Log.d("Pin complete: " , pin);
                pinFlag=true;
                 pins=pin;

            }

            @Override
            public void onEmpty() {

            }

            @Override
            public void onPinChange(int pinLength, String intermediatePin) {
               /* Log.d("Pin changed, new length " .concat(pinLength) ," with intermediate pin " + intermediatePin);*/
            }
        };
        mPinLockView.setPinLockListener(mPinLockListener);

        IndicatorDots mIndicatorDots = (IndicatorDots) findViewById(R.id.indicator_dots);
        mPinLockView.attachIndicatorDots(mIndicatorDots);
        AppCompatButton appCompatButton=(AppCompatButton)findViewById(R.id.btn_signup);
        appCompatButton.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                if(pinFlag){

                    if(pins.equalsIgnoreCase(setPin)){

                        //Set "hasLoggedIn" to true
                        editors.putBoolean("hasLoggedIn", true);

                        // Commit the edits!
                        editors.commit();

                    }
                    else{
                        Toast.makeText(CPinActivity.this, "Pin doesnot match", Toast.LENGTH_LONG).show();
                    }


                    Intent intent = new Intent(CPinActivity.this, Dashboard.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("email","abc");
                    intent.putExtra("name","abc");
                    FragmentManager fragmentManager = CPinActivity.this.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    CPinActivity.this.startActivity(intent);
                    finish();
                    PinActivity.getInstance().finish();

                }
                else{
                    Toast.makeText(CPinActivity.this, "Invalid Pin", Toast.LENGTH_LONG).show();
                }

            }
        });
        AppCompatButton backButton=(AppCompatButton)findViewById(R.id.btn_back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(CPinActivity.this, PinActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                FragmentManager fragmentManager = CPinActivity.this.getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                CPinActivity.this.startActivity(intent);
                finish();

            }
        });

    }
}
