package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.sampleandroidapplication.com.dtos.ContestDTO;
import com.example.sampleandroidapplication.com.dtos.MatchesDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 21-06-2018.
 */

public class UpcomingMatchFragment extends Fragment {

    View v;
    static int i = 0;
    List<MatchesDTO> matchesDTOList = new ArrayList<>();
    SharedPreferences settings;
    LinearLayout linearLayout;
    UpcomingMatchsArrayAdapter upcomingMatchsArrayAdapter;
    ListView listView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.upcoming_matchs, null);
        settings = getActivity().getSharedPreferences("MY_PREFS_NAME", 0);
        String url=getString(R.string.ip_address).concat(getString(R.string.pdata).concat("n"));
        try {
            matchesDTOList = new InvokeWebServiceBannerHomePage(v, getActivity()).execute(url).get();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        linearLayout=(LinearLayout)v.findViewById(R.id.emptydata);
        linearLayout.setVisibility(View.GONE);
            if (matchesDTOList != null || !matchesDTOList.isEmpty()) {

                upcomingMatchsArrayAdapter=new UpcomingMatchsArrayAdapter(v.getContext(),matchesDTOList);
                 listView = (ListView)v.findViewById(R.id.current_match_list);
                listView.setAdapter(upcomingMatchsArrayAdapter);

            }
            else{
                linearLayout.setVisibility(View.VISIBLE);
                return v;
            }
          listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {

if(matchesDTOList.get(position).getResultcomment() !=null){

            FragmentManager fragmentManager = getFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            QuestionAnswersFragment questionAnswersFragment = new QuestionAnswersFragment();
            Bundle bundle = new Bundle();
            bundle.putString("matchId", matchesDTOList.get(position).getMatcheid());
            questionAnswersFragment.setArguments(bundle);
            fragmentTransaction.replace(R.id.fragment_container, questionAnswersFragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        }
    }
});

        return v;

    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}





