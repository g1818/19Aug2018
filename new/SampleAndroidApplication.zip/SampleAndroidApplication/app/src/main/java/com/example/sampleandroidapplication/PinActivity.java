package com.example.sampleandroidapplication;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.pinlockview.IndicatorDots;
import com.andrognito.pinlockview.PinLockListener;
import com.andrognito.pinlockview.PinLockView;

import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class PinActivity extends AppCompatActivity {

    static PinActivity activityA;
    PinLockView mPinLockView;
    Boolean pinFlag=false;
    String pins;
    SharedPreferences settings;
    String setPin;
    private EditText emailEditText;
    private EditText passEditText;
     boolean hasLoggedIn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        activityA = this;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin);
        TextView textView=(TextView)findViewById(R.id.link_pin);
        textView.setVisibility(View.GONE);

        final SharedPreferences.Editor editor = getSharedPreferences("MY_PREFS_NAME", MODE_PRIVATE).edit();
        mPinLockView = (PinLockView) findViewById(R.id.pin_lock_view);
         settings = getSharedPreferences(LoginCheck.Login_check, 0);
        //Get "hasLoggedIn" value. If the value doesn't exist yet false is returned
        hasLoggedIn = settings.getBoolean("hasLoggedIn", false);
        TextView header=(TextView)findViewById(R.id.imageView3);
        if(hasLoggedIn){
            header.setText("Enter Pin");
            textView.setVisibility(View.VISIBLE);
        }
        else{
            header.setText("Set Pin");
        }
        PinLockListener mPinLockListener = new PinLockListener() {
            @Override
            public void onComplete(String pin) {
                Log.d("Pin complete: " , pin);
                pinFlag=true;
                pins=pin;

            }

            @Override
            public void onEmpty() {

            }

            @Override
            public void onPinChange(int pinLength, String intermediatePin) {
               /* Log.d("Pin changed, new length " .concat(pinLength) ," with intermediate pin " + intermediatePin);*/
            }
        };
        mPinLockView.setPinLockListener(mPinLockListener);

        IndicatorDots mIndicatorDots = (IndicatorDots) findViewById(R.id.indicator_dots);
        mPinLockView.attachIndicatorDots(mIndicatorDots);
        AppCompatButton appCompatButton=(AppCompatButton)findViewById(R.id.btn_signup);
        appCompatButton.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {

                if(pinFlag){


                    if(hasLoggedIn) {

                        settings = getSharedPreferences("MY_PREFS_NAME", 0);
                        setPin = settings.getString("pin", "defaultStringIfNothingFound");
                        if (pins.equalsIgnoreCase(setPin)) {
                            Intent intent = new Intent(PinActivity.this, Dashboard.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("email","abc");
                            intent.putExtra("name","abc");
                            FragmentManager fragmentManager = PinActivity.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            PinActivity.this.startActivity(intent);
                            finish();


                        } else {
                            Toast.makeText(PinActivity.this, "Invalid Pin", Toast.LENGTH_LONG).show();
                        }
                    }
                    else {

                        editor.putString("pin", pins);
                        editor.commit();
                        Intent intent = new Intent(PinActivity.this, CPinActivity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        FragmentManager fragmentManager = PinActivity.this.getSupportFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        startActivity(intent);
                    }

                }
                else{

                    Toast.makeText(PinActivity.this, "Invalid Pin", Toast.LENGTH_LONG).show();
                }

            }
        });


        TextView text = (TextView) findViewById(R.id.link_pin);
        text.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {


                final Dialog dialog = new Dialog(PinActivity.this);
                dialog.setContentView(R.layout.custom_dialog);
                dialog.setTitle("Set Pin");
                dialog.show();
                AppCompatButton declineButton = (AppCompatButton) dialog.findViewById(R.id.btn_back);
                // if decline button is clicked, close the custom dialog
                declineButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Close dialog
                        dialog.dismiss();
                    }
                });
                TextView linkText=(TextView)dialog.findViewById(R.id.link_pin);
                linkText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                        final Dialog secondDialog = new Dialog(PinActivity.this);
                        secondDialog.setContentView(R.layout.forgot_password);
                        secondDialog.setTitle("Set Password");
                        secondDialog.show();
                        AppCompatButton declineButton = (AppCompatButton) secondDialog.findViewById(R.id.btn_back);
                        // if decline button is clicked, close the custom dialog
                        declineButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                // Close dialog
                                secondDialog.dismiss();
                            }
                        });

                        AppCompatButton AcceptButtons = (AppCompatButton) secondDialog.findViewById(R.id.btn_signup);
                        // if decline button is clicked, close the custom dialog
                        AcceptButtons.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                               EditText  emaiText = (EditText)secondDialog.findViewById(R.id.editText_email);
                                boolean isValidate=true;
                                final String emails=emaiText.getText().toString();
                                if (!com.example.sampleandroidapplication.SignupActivity.isValidEmail(emails)) {
                                    emaiText.setError("Invalid Email");
                                    isValidate=false;
                                }
                                if(isValidate){

                                    try {
                                        String url = getString(R.string.ip_address).concat(getString(R.string.forgot_password));
                                        String status=new InvokeWebServiceForForgotPassword(emaiText.getText().toString()).execute(url).get();
                                        secondDialog.dismiss();
                                        if(status.equalsIgnoreCase("true"))
                                        Toast.makeText(PinActivity.this, "Password has been sent to your Mail Id", Toast.LENGTH_LONG).show();
                                        else
                                            Toast.makeText(PinActivity.this, "Incorrect Mail Id", Toast.LENGTH_LONG).show();

                                    }
                                    catch (Exception e){
                                        e.printStackTrace();
                                    }

                                }
                                else{
                                    return;
                                    /*Toast.makeText(PinActivity.this, "Invalid Credentials", Toast.LENGTH_LONG).show();*/
                                }



                            }
                        });

                    }
                });


                AppCompatButton AcceptButton = (AppCompatButton) dialog.findViewById(R.id.btn_signup);
                // if decline button is clicked, close the custom dialog
                AcceptButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        emailEditText = (EditText)dialog.findViewById(R.id.editText_email);
                        passEditText = (EditText)dialog.findViewById(R.id.editText_password);

                        boolean isValidate=true;
                        final String email=emailEditText.getText().toString();
                        if (!com.example.sampleandroidapplication.SignupActivity.isValidEmail(email)) {
                            emailEditText.setError("Invalid Email");
                            isValidate=false;
                        }
                        final String pass = passEditText.getText().toString();
                        if (!com.example.sampleandroidapplication.SignupActivity.isValidPassword(pass)) {
                            passEditText.setError("Invalid Password");
                            isValidate=false;
                        }
                        if(isValidate){

                            String url=getString(R.string.ip_address).concat(getString(R.string.login)).concat(emailEditText.getText().toString()).concat(getString(R.string.inputpassword))
                                    .concat(passEditText.getText().toString());
                            new InvokeWebServiceForSignupLogin(getApplicationContext(),PinActivity.this,2,passEditText.getText().toString()).execute(url);
                            dialog.dismiss();
                        }
                        else{
                              return;
                            /*Toast.makeText(PinActivity.this, "Invalid Credentials", Toast.LENGTH_LONG).show();*/
                        }



                    }
                });



                   /* Intent intent = new Intent(SignupActivity.this, PinActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    FragmentManager fragmentManager = SignupActivity.this.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    SignupActivity.this.startActivity(intent);
                    finish();*/


            }
        });

/*
        if (hasLoggedIn) {



        }

        else{




        }*/
    }
    public static PinActivity getInstance(){
        return   activityA;
    }
}
class InvokeWebServiceForForgotPassword extends AsyncTask<String, Void, String> {
    StringBuffer sb = new StringBuffer();
    String userName;

    InvokeWebServiceForForgotPassword(String userName) {

        this.userName=userName;

    }

    @Override
    protected String doInBackground(String... strings) {

        try {
            JSONObject post_dict = new JSONObject();
            post_dict.put("EMAIL", userName); //cll a function

            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(strings[0]).openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST"); // here you are telling that it is a POST request, which can be changed into "PUT", "GET", "DELETE" etc.
            httpURLConnection.setRequestProperty("Content-Type", "application/json"); // here you are setting the `Content-Type` for the data you are sending which is `application/json`
            httpURLConnection.connect();

            DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
            wr.writeBytes(post_dict.toString());
            wr.flush();
            wr.close();
            int responseCode = httpURLConnection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(
                                httpURLConnection.getInputStream()));

                String line = "";

                while ((line = in.readLine()) != null) {

                    sb.append(line);
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}