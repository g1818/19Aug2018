/*
package com.example.sampleandroidapplication;

*/
/**
 * Created by Ashwini.R on 11-06-2018.
 *//*


import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class SMTPAuthenticator extends Authenticator {
    public SMTPAuthenticator() {

        super();
    }

    @Override
    public PasswordAuthentication getPasswordAuthentication() {
        String username = "mlndrdtst@gmail.com";
        String password = "Admin@123";
        if ((username != null) && (username.length() > 0) && (password != null)
                && (password.length() > 0)) {

            return new PasswordAuthentication(username, password);
        }

        return null;
    }
}*/
