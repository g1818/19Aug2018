package com.example.sampleandroidapplication.com.dtos;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by Ashwini.R on 26-04-2018.
 */

public class CustomerDateAndTimeDeserialize extends JsonDeserializer<Date> {



    @Override
    public Date deserialize(JsonParser paramJsonParser,
                            DeserializationContext paramDeserializationContext)
            throws IOException, JsonProcessingException {


        String str = paramJsonParser.getText();

        SimpleDateFormat readFormat =new SimpleDateFormat("MMM dd, yyyy hh:mm:ss a", Locale.US);

        Date formatDate=null;
        DateFormat writeFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = readFormat.parse(str);


            String formattedDate = "";
            if (date != null) {
                formattedDate = writeFormat.format(date);
            }
            formatDate=   writeFormat.parse(formattedDate);
        }
          catch ( Exception e ) {
            e.printStackTrace();
        }
        return formatDate;
    }
}