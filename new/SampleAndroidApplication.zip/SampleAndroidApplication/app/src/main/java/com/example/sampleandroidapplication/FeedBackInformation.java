package com.example.sampleandroidapplication;

import android.app.FragmentManager;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.paytm.pgsdk.PaytmClientCertificate;
import com.paytm.pgsdk.PaytmMerchant;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class FeedBackInformation extends Fragment {
    private EditText titleEditText;
    private EditText commentEdiText;
    View v;
     ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.feedback, null);
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        titleEditText = (EditText)v.findViewById(R.id.editText_topic);
        commentEdiText = (EditText)v.findViewById(R.id.editText_comments);
        v.findViewById(R.id.btn_submit).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                boolean isValidate = true;
                if (!isValid(titleEditText.getText().toString())) {
                    titleEditText.setError("Enter minimum 3 character");
                    isValidate = false;
                }
                final String pass = commentEdiText.getText().toString();
                if (!isValid(pass)) {
                    commentEdiText.setError("Enter minimum 3 character");
                    isValidate = false;
                }
                if (isValidate) {

                    String url = getString(R.string.ip_address).concat(getString(R.string.feedback));
                    SharedPreferences settings = v.getContext().getSharedPreferences("MY_PREFS_NAME", 0);
                    String userEmail = settings.getString("username", "abc");
                    try {
                        progressDialog = ProgressDialog.show(v.getContext(), "Loading", "Please wait a moment!");
                        String status = new InvokeWebServiceForFeedBack(userEmail, titleEditText.getText().toString(), commentEdiText.getText().toString()).execute(url).get();
                        if (progressDialog.isShowing()) progressDialog.dismiss();
                        if (status.equalsIgnoreCase("true")) {
                            Intent intent = new Intent(view.getContext(), Dashboard.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            intent.putExtra("email", "abc");
                            intent.putExtra("name", "abc");
                            view.getContext().startActivity(intent);
                            Toast.makeText(view.getContext(), "Feedback submitted successfully", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(view.getContext(), "Error in submitted feedback!! try again later", Toast.LENGTH_LONG).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });
       return v;
    }
    private boolean isValid(String pass) {
        if (pass != null && pass.length() > 3) {
            return true;
        }
        return false;
    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }

}
class InvokeWebServiceForFeedBack extends AsyncTask<String, Void, String> {
    StringBuffer sb = new StringBuffer();
    String subject, comment;
    String userName;

    InvokeWebServiceForFeedBack(String userName,String subject, String comment) {

        this.userName=userName;
        this.subject = subject;
        this.comment = comment;
    }

    @Override
    protected String doInBackground(String... strings) {

        try {
            JSONObject post_dict = new JSONObject();
            post_dict.put("subject", subject); //cll a function
            post_dict.put("body", comment);
            post_dict.put("userName", userName);

            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(strings[0]).openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST"); // here you are telling that it is a POST request, which can be changed into "PUT", "GET", "DELETE" etc.
            httpURLConnection.setRequestProperty("Content-Type", "application/json"); // here you are setting the `Content-Type` for the data you are sending which is `application/json`
            httpURLConnection.connect();

            DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
            wr.writeBytes(post_dict.toString());
            wr.flush();
            wr.close();
            int responseCode = httpURLConnection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(
                                httpURLConnection.getInputStream()));

                String line = "";

                while ((line = in.readLine()) != null) {

                    sb.append(line);
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}