package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.Settings;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.sampleandroidapplication.com.dtos.MatchesDTO;
import com.example.sampleandroidapplication.com.dtos.SeriesDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import me.relex.circleindicator.CircleIndicator;

/**
 * Created by Ashwini.R on 30-05-2018.
 */

public class HomePage extends Fragment {

    private AdView mAdView;
    Handler mHandler;
    private static ViewPager mPager;
    public  List<MatchesDTO> rankDTOList = new ArrayList<>();
    ListViewArrayAdapter listViewArrayAdapter;
    String url;
    private static final Integer[] XMEN= {R.drawable.pvsi,R.drawable.pvsi,R.drawable.pvsi,R.drawable.pvsi};
    private static int currentPage = 0;
  /*  String[] mobileArray = {"Android","IPhone","WindowsMobile","Blackberry",
            "WebOS","Ubuntu","Windows7","Max OS X","IPhone","IPhone"};*/
     ArrayList<String> mobile=new ArrayList<>();
     
    private ArrayList<Integer> XMENArray = new ArrayList<Integer>();
    View v;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.homepage, null);
        init();
        mobile.clear();
        mobile.add("Current Match");
        mobile.add("Recent Results");
        mobile.add("Upcoming Matches");
        getBannerDetails();

        listViewArrayAdapter=new ListViewArrayAdapter(v.getContext(),mobile);
       /* String android_id = Settings.Secure.getString(v.getContext().getContentResolver(),
                Settings.Secure.ANDROID_ID);*/
       mAdView = v.findViewById(R.id.adView);
        mAdView.setVisibility(View.VISIBLE);

        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        ListView listView = (ListView)v.findViewById(R.id.mobile_list);
        listView.setAdapter(listViewArrayAdapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String entry = (String) adapterView.getItemAtPosition(i);
                Log.i("Item Selected",entry);
                if(entry.equalsIgnoreCase("Current Match")){

                    FragmentManager fragmentManager = getFragmentManager();
                    ProgressMatchFragment progressMatchFragment=new ProgressMatchFragment();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.fragment_container, progressMatchFragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                }
                else if(entry.equalsIgnoreCase("Upcoming Matches")){


                    FragmentManager fragmentManager = getFragmentManager();
                    UpcomingMatchFragment upcomingMatchFragment=new UpcomingMatchFragment();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.fragment_container, upcomingMatchFragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();


                }
               else if(entry.equalsIgnoreCase("Recent Results")){

                    FragmentManager fragmentManager = getFragmentManager();
                    MatchFragment matchFragment=new MatchFragment();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    fragmentTransaction.replace(R.id.fragment_container, matchFragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                }

            }
        });
      /*  url=getString(R.string.ip_address).concat(getString(R.string.pdata));*/
  /*     mHandler = new Handler();
        new Thread(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub
                while (true) {
                    try {
                        Thread.sleep(10000);
                        mHandler.post(new Runnable() {

                            @Override
                            public void run() {
                                Log.i("url",url);*/
                             /*   new InvokeWebServiceBannerHomePage(v,getActivity()).execute(url);*/
                          /*  }
                        });
                    } catch (Exception e) {
                        // TODO: handle exception
                    }
                }
            }
        }).start();
*/
        return v;
    }
    @Override
    public void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }


    @Override
    public void onResume() {
        super.onResume();
        if (mAdView != null) {
            getBannerDetails();
            mAdView.resume();
        }

    }

    @Override
    public void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        super.onDestroy();
    }
    private void init() {
        XMENArray.clear();
        for(int i=0;i<XMEN.length;i++) {
            XMENArray.add(XMEN[i]);
        }
        }

public void getBannerDetails(){
    String url=getString(R.string.ip_address).concat(getString(R.string.bannerDestails));
    try {
        rankDTOList = new InvokeWebServiceBannerHomePage(v, getActivity()).execute(url).get();
    }
    catch (Exception e){
        e.printStackTrace();
    }
    if (rankDTOList != null || !rankDTOList.isEmpty()) {
        mPager = (ViewPager)v.findViewById(R.id.pager);
        mPager.setAdapter(new HomePagerAdapter(getFragmentManager(),rankDTOList));
        CircleIndicator indicator = (CircleIndicator)v.findViewById(R.id.indicator);
        indicator.setViewPager(mPager);
    }

    }


        // Auto start of viewpager
        final Handler handler = new Handler();
       /* final Runnable Update = new Runnable() {
            public void run() {
                if (currentPage == XMEN.length) {
                    currentPage = 0;
                }
                mPager.setCurrentItem(currentPage++, true);
            }
        };*/
       /* Timer swipeTimer = new Timer();
        swipeTimer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.post(Update);
            }
        }, 5000, 1000);*/
    }



class InvokeWebServiceBannerHomePage extends AsyncTask<String,Void,List<MatchesDTO>> {

    View view;

    private ProgressDialog progressDialog;
    FragmentActivity fragmentActivity;
    public  List<MatchesDTO> rankDTOList = new ArrayList<>();

    InvokeWebServiceBannerHomePage(View v, FragmentActivity fragmentActivity) {

        view = v;
        this.fragmentActivity = fragmentActivity;

    }

    @Override
    protected void onPreExecute() {

      /*  progressDialog = ProgressDialog.show(view.getContext(), "Loading", "Please wait a moment!");*/
    }

    @Override
    protected List<MatchesDTO> doInBackground(String... strings) {

        StringBuffer buffer = new StringBuffer();
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line = "";
            while ((line = bf.readLine()) != null) {
                buffer.append(line);
            }

            ObjectMapper mapperObject = new ObjectMapper();
            rankDTOList = mapperObject.readValue(buffer.toString(), mapperObject.getTypeFactory().constructCollectionType(List.class, MatchesDTO.class));
            System.out.println("inside postexecute=" + rankDTOList.size());


        } catch (Exception e) {
            e.printStackTrace();
        }

        return rankDTOList;
    }
}


