package com.example.sampleandroidapplication;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.PagerAdapter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.MatchesDTO;
import com.example.sampleandroidapplication.com.dtos.SeriesDTO;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 30-05-2018.
 */

public class HomePageFragment   extends Fragment implements View.OnClickListener {

    View v;
    MatchesDTO matchesDTO;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.activity_listview_homepage_tab, container, false);
        Bundle args = getArguments();
        matchesDTO = (MatchesDTO) args.getSerializable("menus");
        int position=args.getInt("position");


            TextView textView = (TextView) v.findViewById(R.id.label1);
        TextView textView2 = (TextView) v.findViewById(R.id.label2);
        TextView textView3 = (TextView) v.findViewById(R.id.label3);
        TextView textView4 = (TextView) v.findViewById(R.id.label4);
        TextView textView5 = (TextView) v.findViewById(R.id.label5);
        TextView textView6 = (TextView) v.findViewById(R.id.label6);


        textView.setText(matchesDTO.getMatchcomment()+" In "+matchesDTO.getVenue());
        textView.setOnClickListener(this);
        textView2.setText(matchesDTO.getFirstTeam());
        textView2.setOnClickListener(this);
        textView3.setOnClickListener(this);
        textView4.setOnClickListener(this);
        textView5.setOnClickListener(this);
        textView6.setOnClickListener(this);
        textView3.setText(matchesDTO.getFirstteamscore());
        textView4.setText(matchesDTO.getSecondTeam());
        textView5.setText(matchesDTO.getSecondteamscore());
        textView6.setText(matchesDTO.getResultcomment());



        return v;
    }
    @Override
    public void onClick(View view) {

  /*      FragmentManager fragmentManager = getFragmentManager();
        QuestionAnswersFragment questionAnswersFragment1=new QuestionAnswersFragment();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, questionAnswersFragment1);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();*/

  if(matchesDTO.getResultcomment() != null) {

      FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
      Fragment questionAnswersFragment = new QuestionAnswersFragment();
      Bundle bundle = new Bundle();
      bundle.putString("matchId", matchesDTO.getMatcheid());
      Log.i("Value set is ", matchesDTO.getMatcheid());
      questionAnswersFragment.setArguments(bundle);
      FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
      fragmentTransaction.replace(R.id.fragment_container, questionAnswersFragment);
      fragmentTransaction.addToBackStack(null);
      fragmentTransaction.commit();

  }

    }
}
