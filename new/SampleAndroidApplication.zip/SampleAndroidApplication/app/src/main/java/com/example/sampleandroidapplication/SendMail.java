/*
package com.example.sampleandroidapplication;

*/
/**
 * Created by Ashwini.R on 11-06-2018.
 *//*

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;


public class SendMail extends AsyncTask<String, Integer, Void> {


    Context context;
    AppCompatActivity mainActivity;
    SendMail(Context context,
             AppCompatActivity mainActivity) {

        this.context=context;
        this.mainActivity=mainActivity;
    }


    @Override
    protected void onPreExecute() {
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        */
/*if(progressDialog.isShowing())progressDialog.dismiss();*//*


    }

    protected Void doInBackground(String... params) {
        Mail m = new Mail("mlndrdtst@gmail.com", "Admin@123");

        String[] toArr = {params[0], "mlndrdtst@gmail.com"};
        m.setTo(toArr);
        m.setFrom("mlndrdtst@gmail.com");
        m.setSubject("Sucessfully created account.");
        m.setBody("Email body.");

        try {
            if(m.send()) {

            } else {
            }
        } catch(Exception e) {
            Log.e("MailApp", "Could not send email", e);
        }
        return null;
    }
}



*/
