package com.example.sampleandroidapplication;

import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.MatchesDTO;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 21-06-2018.
 */

public class BalanceFragment extends Fragment {

    View v;
    static int i = 0;
    SharedPreferences settings;
    ListView listView;
    TextView amount;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.balance, null);
        settings = getActivity().getSharedPreferences("MY_PREFS_NAME", 0);
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        try {
            String url = getString(R.string.ip_address).concat(getString(R.string.userbalance));
            SharedPreferences settings = v.getContext().getSharedPreferences("MY_PREFS_NAME", 0);
            String userEmail = settings.getString("username", "abc");
            final String status = new InvokeWebServiceForBalance(userEmail).execute(url).get();
            LinearLayout linearLayout=(LinearLayout)v.findViewById(R.id.amount);
            LinearLayout emptyLayout=(LinearLayout)v.findViewById(R.id.emptydata);

           if(status.equalsIgnoreCase("0")){

                linearLayout.setVisibility(View.GONE);
                emptyLayout.setVisibility(View.VISIBLE);
            }
            else{
                linearLayout.setVisibility(View.VISIBLE);
                emptyLayout.setVisibility(View.GONE);
            }
            amount = (TextView) v.findViewById(R.id.amounttext);
            amount.setText(status.concat("Rs"));

            Button button = (Button) v.findViewById(R.id.btn_addtobank);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    FragmentManager fragmentManager = getFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    Bundle bundle = new Bundle();
                    bundle.putString("amt", status);
                    AddToBankInformation addToBankInformation = new AddToBankInformation();
                    addToBankInformation.setArguments(bundle);
                    fragmentTransaction.replace(R.id.fragment_container, addToBankInformation);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();

                }
            });
        }
        catch(Exception e){
            e.printStackTrace();
        }


        return v;

    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}
class InvokeWebServiceForBalance extends AsyncTask<String, Void, String> {
    StringBuffer sb = new StringBuffer();
    String userName;

    InvokeWebServiceForBalance(String userName) {

        this.userName=userName;

    }

    @Override
    protected String doInBackground(String... strings) {

        try {
            JSONObject post_dict = new JSONObject();
            post_dict.put("userEmail", userName);

            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(strings[0]).openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST"); // here you are telling that it is a POST request, which can be changed into "PUT", "GET", "DELETE" etc.
            httpURLConnection.setRequestProperty("Content-Type", "application/json"); // here you are setting the `Content-Type` for the data you are sending which is `application/json`
            httpURLConnection.connect();

            DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
            wr.writeBytes(post_dict.toString());
            wr.flush();
            wr.close();
            int responseCode = httpURLConnection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(
                                httpURLConnection.getInputStream()));

                String line = "";

                while ((line = in.readLine()) != null) {

                    sb.append(line);
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}


