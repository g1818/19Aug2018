package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.SparseArray;

import com.example.sampleandroidapplication.com.dtos.MatchesDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 14-06-2018.
 */

public class StepWisePagerAdapter extends FragmentStatePagerAdapter {
    SparseArray<Fragment> registeredFragments = new SparseArray<Fragment>();
    List<String> stepWiseNames=new ArrayList<>();


    public StepWisePagerAdapter(FragmentManager fm) {
        super(fm);
        stepWiseNames.add("Select Matchs");
        stepWiseNames.add("Create Team");
        stepWiseNames.add("Join Contests");

    }
    @Override
    public int getCount() {

        return 3;
    }


    @Override
    public Fragment getItem(int position) {
        Bundle arguments = new Bundle();
        Tab1 fragment = new Tab1();
        fragment.setArguments(arguments);
        return fragment;
    }

    @Override
    public CharSequence getPageTitle(int position) {

        if(position==0)
            return "Select Matchs";
        else   if(position==1)
            return "Create Team";

        else
            return "Join Contests";
        }
    }
