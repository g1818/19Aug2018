package com.example.sampleandroidapplication;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.PlayersDTO;
import com.example.sampleandroidapplication.com.dtos.SeriesDTO;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created by Guna.Sekhar on 6/13/2018.
 */

public class BrowsePlayersArrayAdapter extends ArrayAdapter<PlayersDTO> {

    Context context;
    List<PlayersDTO> user;


    public BrowsePlayersArrayAdapter(Context context, List<PlayersDTO> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }
    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        String text=user.get(position).getPlayername().concat("\n").concat(user.get(position).getCountry());
        View rowView = inflater.inflate(R.layout.browse_players_listview, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label1);
        textView.setCompoundDrawablesWithIntrinsicBounds(R.drawable.player, 0, 0, 0);
        textView.setText(text);
/*        SimpleDateFormat formater = new SimpleDateFormat("dd-MM-yyyy");
        String format = formater.format(user.get(position).getStartDate());
        String format1 = formater.format(user.get(position).getEnd_date());*/
       /* TableRow.LayoutParams lc$param = new TableRow.LayoutParams();
        lc$param.height = GridLayout.LayoutParams.WRAP_CONTENT;
        lc$param.width = dpToPx(120);

        TableRow.LayoutParams lc$params = new TableRow.LayoutParams();
        lc$params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        lc$params.width = dpToPx(200);*/
        /*else{
            textView2.setCompoundDrawablesWithIntrinsicBounds(R.drawable.live_help, 0, 0, 0);
        }*/

        return rowView;
    }

}