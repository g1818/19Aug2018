package com.example.sampleandroidapplication;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.SeriesDTO;
import com.example.sampleandroidapplication.com.dtos.TeamsDTO;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created by Guna.Sekhar on 6/13/2018.
 */

public class BrowseTeamArrayAdapter extends ArrayAdapter<TeamsDTO> {

    Context context;
    List<TeamsDTO> user;


    public BrowseTeamArrayAdapter(Context context, List<TeamsDTO> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }
    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.activity_listview, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label1);
        textView.setText(user.get(position).getTeamname());
        return rowView;
    }

}