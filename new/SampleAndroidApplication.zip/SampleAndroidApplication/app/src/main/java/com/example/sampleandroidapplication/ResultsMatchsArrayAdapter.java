package com.example.sampleandroidapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.MatchWinDTO;
import com.example.sampleandroidapplication.com.dtos.UserQuestionAnswerDTO;

import java.util.List;

/**
 * Created by Ashwini.R on 31-05-2018.
 */

public class ResultsMatchsArrayAdapter extends ArrayAdapter<MatchWinDTO> {

    Context context;
    List<MatchWinDTO> user;


    public ResultsMatchsArrayAdapter(Context context, List<MatchWinDTO> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.results_listview, parent, false);
        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        TextView textView4=(TextView)rowView.findViewById(R.id.label4);
        TextView textView6=(TextView)rowView.findViewById(R.id.label6);
        textView2.setText(user.get(position).getEmail());
        textView4.setText(user.get(position).getName());
        textView6.setText(user.get(position).getPonits());
        return rowView;
    }

}
