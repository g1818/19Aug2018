package com.example.sampleandroidapplication.com.dtos;

/**
 * Created by Guna Sekhar on 26-06-2018.
 */

public class MatchWinDTO  {


	 private 	String name;
	 private 	String ponits;
	 private 	String email;
	 
	 
	 
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPonits() {
		return ponits;
	}
	public void setPonits(String ponits) {
		this.ponits = ponits;
	}
	    
	    
	  
	    


  
}
