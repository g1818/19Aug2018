package com.example.sampleandroidapplication;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.provider.Settings;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;

import java.net.URI;

public class Dashboard extends AppCompatActivity {
   /* private AdView mAdView;*/
    private DrawerLayout mDrawerLayout;
    String userName;
    SharedPreferences settings;
    String userEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        String android_id = Settings.Secure.getString(Dashboard.this.getContentResolver(),
                Settings.Secure.ANDROID_ID);

        Bundle extras = getIntent().getExtras();
        settings = getSharedPreferences("MY_PREFS_NAME", 0);

        if (extras != null) {

            userName=settings.getString("name","abc");
            userEmail=settings.getString("username","abc");
        }

      /*  mAdView = findViewById(R.id.adView);
        mAdView.setVisibility(View.VISIBLE);
        AdRequest adRequest = new AdRequest.Builder()
                .addTestDevice(AdRequest.DEVICE_ID_EMULATOR)        // All emulators
                .addTestDevice(android_id)  // My Galaxy Nexus test phone
                .build();

        mAdView.loadAd(adRequest);
*/

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar actionbar =getSupportActionBar();
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        actionbar.setDisplayHomeAsUpEnabled(true);
        actionbar.setHomeAsUpIndicator(R.drawable.ic_menu_black_24dp);
        actionbar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#00BCD4")));
        mDrawerLayout = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        View view=navigationView.getHeaderView(0);
        TextView name=(TextView)view.findViewById(R.id.username) ;
        TextView email=(TextView)view.findViewById(R.id.useremail) ;
        name.setText(userName);
        email.setText(userEmail);
        navigationView.getMenu().getItem(0).setChecked(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {


                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        // set item as selected to persist highlight
                        menuItem.setChecked(false);
          /*              mAdView.setVisibility(View.GONE);*/
                        if(menuItem.toString().equalsIgnoreCase("Records")){

                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            RecordsPage recordsPage = new RecordsPage();
                            fragmentTransaction.replace(R.id.fragment_container, recordsPage);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }
                        else if(menuItem.toString().equalsIgnoreCase("Browse Teams")) {



                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            BrowseTeam browseTeam = new BrowseTeam();
                            fragmentTransaction.replace(R.id.fragment_container, browseTeam);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }

                        else if(menuItem.toString().equalsIgnoreCase("Browse Players")) {

                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            BrowsePlayers browseTeam = new BrowsePlayers();
                            fragmentTransaction.replace(R.id.fragment_container, browseTeam);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }

                        else if(menuItem.toString().equalsIgnoreCase("Browse Series")) {

                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            BrowseSeries browseSeries = new BrowseSeries();
                            fragmentTransaction.replace(R.id.fragment_container, browseSeries);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }
                        else if(menuItem.toString().equalsIgnoreCase("Quotes")) {

                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            NewsQuotes browseSeries = new NewsQuotes();
                            fragmentTransaction.replace(R.id.fragment_container, browseSeries);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }

                        else if(menuItem.toString().equalsIgnoreCase("Rate the app")) {

                            Uri uri= Uri.parse("market://details?id="+getPackageName());
                            Intent myAppLinkToMarket=new Intent(Intent.ACTION_VIEW, uri);
                            try{
                                startActivity(myAppLinkToMarket);
                            }
                            catch (ActivityNotFoundException e){
                                Toast.makeText(Dashboard.this, "Unable to find market app", Toast.LENGTH_LONG).show();
                            }

                        }

                        else if(menuItem.toString().equalsIgnoreCase("Ranking")) {

                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            RankingPage rankingPage = new RankingPage();
                            fragmentTransaction.replace(R.id.fragment_container, rankingPage);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }

                        else if(menuItem.toString().equalsIgnoreCase("User Information")) {

                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            UserInformation  userInformation = new UserInformation();
                            fragmentTransaction.replace(R.id.fragment_container, userInformation);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }
                        else if(menuItem.toString().equalsIgnoreCase("Feedback")) {




                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            FeedBackInformation  feedBackInformation = new FeedBackInformation();
                            fragmentTransaction.replace(R.id.fragment_container, feedBackInformation);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }
                        else if(menuItem.toString().equalsIgnoreCase("Balance Info")){

                            FragmentManager fragmentManager = Dashboard.this.getSupportFragmentManager();
                            BalanceFragment balanceFragment=new BalanceFragment();
                            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                            fragmentTransaction.replace(R.id.fragment_container, balanceFragment);
                            fragmentTransaction.addToBackStack(null);
                            fragmentTransaction.commit();

                        }
                        else if(menuItem.toString().equalsIgnoreCase("Logout")){

                            Intent intent = new Intent(Dashboard.this, SignupActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                            finish();
                        }

                        mDrawerLayout.closeDrawers();
                        // Add code here to update the UI based on the item selected
                        // For example, swap UI fragments here
                        return false;
                    }
                });


        FragmentManager fragmentManager =Dashboard.this.getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        HomePage homePage=new HomePage();
        fragmentTransaction.replace(R.id.fragment_container, homePage);
        fragmentTransaction.commit();

    }


   /* @Override
    public void onPause() {
        if (mAdView != null) {
            mAdView.pause();
        }
        super.onPause();
    }

    *//** Called when returning to the activity *//*
    @Override
    public void onResume() {
        super.onResume();
        if (mAdView != null) {
            mAdView.resume();
        }
    }

    *//** Called before the activity is destroyed *//*
    @Override
    public void onDestroy() {
        if (mAdView != null) {
            mAdView.destroy();
        }
        super.onDestroy();
    }*/


    @Override
    public void onBackPressed() {

        if (this.mDrawerLayout.isDrawerOpen(GravityCompat.START)) {
            this.mDrawerLayout.closeDrawer(GravityCompat.START);
            return ;
        }

        if (getFragmentManager().getBackStackEntryCount() > 0) {
            getFragmentManager().popBackStack();
      /*    mAdView.setVisibility(View.VISIBLE);*/
        }

        else {
/*           mAdView.setVisibility(View.VISIBLE);*/
            super.onBackPressed();
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
        }


        return super.onOptionsItemSelected(item);
    }
}
