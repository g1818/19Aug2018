package com.example.sampleandroidapplication;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatButton;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SignupActivity extends AppCompatActivity {

    EditText name;
    EditText username;
    EditText password;
    EditText cpassword;
    EditText pnumber;
    private EditText emailEditText;
    private EditText passEditText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences settings = getSharedPreferences(LoginCheck.Login_check, 0);
        //Get "hasLoggedIn" value. If the value doesn't exist yet false is returned
      //boolean hasLoggedIn=  settings.getBoolean("hasLoggedIn", false);
     boolean hasLoggedIn = false;
        if (hasLoggedIn) {
            Intent intent = new Intent(SignupActivity.this, PinActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            FragmentManager fragmentManager = SignupActivity.this.getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            startActivity(intent);
            finish();
            SignupActivity.this.finish();

        } else {

            setContentView(R.layout.activity_signup);
            name = (EditText) findViewById(R.id.input_name);
            username = (EditText) findViewById(R.id.input_email);
            password = (EditText) findViewById(R.id.input_password);
            cpassword=(EditText)findViewById(R.id.input_cpassword);
            pnumber=(EditText)findViewById(R.id.input_pnumber);
            AppCompatButton appCompatButton = (AppCompatButton) findViewById(R.id.btn_signup);
            appCompatButton.setOnClickListener(new View.OnClickListener() {


                @Override
                public void onClick(View view) {

                    Boolean isValidate = true;
                    if (name.getText().toString().equalsIgnoreCase("") || name.getText().toString().isEmpty()) {
                        name.setError("Enter Name");
                        isValidate = false;
                    }
                    if (!isValidEmail(username.getText().toString())) {
                        username.setError("Enter valid Email");
                        isValidate = false;
                    }
                    if (!isValidPassword(password.getText().toString())) {
                        password.setError("Make sure password contains uppercase,lowercase,special character and digit");
                        isValidate = false;
                    }
                    if(!cpassword.getText().toString().equalsIgnoreCase(password.getText().toString())){

                        cpassword.setError("Confirm password doesnot match password");
                        isValidate = false;
                    }
                    if(!android.util.Patterns.PHONE.matcher(pnumber.getText()).matches()){

                        pnumber.setError("Verify Phone Number");
                        isValidate = false;
                    }

                    if (isValidate) {


                         String url=getString(R.string.ip_address).concat(getString(R.string.userCreation)).concat(name.getText().toString().trim())
                                 .concat(getString(R.string.inputpassword)).concat(password.getText().toString().trim()).concat(getString(R.string.inputphone).trim()).concat(pnumber.getText().toString().trim())
                                 .concat(getString(R.string.inputemail)).concat(username.getText().toString());
                         Log.i("URL",getString(R.string.ip_address).concat(getString(R.string.userCreation)).concat(name.getText().toString())
                                 .concat(getString(R.string.inputpassword)).concat(password.getText().toString()).concat(getString(R.string.inputphone)).concat(pnumber.getText().toString())
                                 .concat(getString(R.string.inputemail)).concat(username.getText().toString()));
                        new InvokeWebServiceForSignupLogin(getApplicationContext(),SignupActivity.this,1,password.getText().toString()).execute(url);

                    } else {
                        Toast.makeText(SignupActivity.this, "Ensure all details are correct and try again", Toast.LENGTH_LONG).show();
                    }

                }
            });

            TextView textView = (TextView) findViewById(R.id.link_login);
            textView.setOnClickListener(new View.OnClickListener() {


                @Override
                public void onClick(View view) {


                    final Dialog dialog = new Dialog(SignupActivity.this);
                    dialog.setContentView(R.layout.custom_dialog);
                    dialog.setTitle("Set Pin");
                    dialog.show();
                    AppCompatButton declineButton = (AppCompatButton) dialog.findViewById(R.id.btn_back);
                    // if decline button is clicked, close the custom dialog
                    declineButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // Close dialog
                            dialog.dismiss();
                        }
                    });
                    TextView linkText=(TextView)dialog.findViewById(R.id.link_pin);
                    linkText.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialog.dismiss();
                            final Dialog secondDialog = new Dialog(SignupActivity.this);
                            secondDialog.setContentView(R.layout.forgot_password);
                            secondDialog.setTitle("Set Password");
                            secondDialog.show();
                            AppCompatButton declineButton = (AppCompatButton) secondDialog.findViewById(R.id.btn_back);
                            // if decline button is clicked, close the custom dialog
                            declineButton.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    // Close dialog
                                    secondDialog.dismiss();
                                }
                            });

                            AppCompatButton AcceptButtons = (AppCompatButton) secondDialog.findViewById(R.id.btn_signup);
                            // if decline button is clicked, close the custom dialog
                            AcceptButtons.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    EditText  emaiText = (EditText)secondDialog.findViewById(R.id.editText_email);
                                    boolean isValidate=true;
                                    final String emails=emaiText.getText().toString();
                                    if (!com.example.sampleandroidapplication.SignupActivity.isValidEmail(emails)) {
                                        emaiText.setError("Invalid Email");
                                        isValidate=false;
                                    }
                                    if(isValidate){

                                        try {
                                            String url = getString(R.string.ip_address).concat(getString(R.string.forgot_password));
                                            String status=new InvokeWebServiceForForgotPassword(emaiText.getText().toString()).execute(url).get();
                                            secondDialog.dismiss();
                                            if(status.equalsIgnoreCase("true"))
                                                Toast.makeText(SignupActivity.this, "Password has been sent to your Mail Id", Toast.LENGTH_LONG).show();
                                            else
                                                Toast.makeText(SignupActivity.this, "Incorrect Mail Id", Toast.LENGTH_LONG).show();

                                        }
                                        catch (Exception e){
                                            e.printStackTrace();
                                        }

                                    }
                                    else{
                                        return;
                                        /*Toast.makeText(PinActivity.this, "Invalid Credentials", Toast.LENGTH_LONG).show();*/
                                    }



                                }
                            });

                        }
                    });
                    AppCompatButton AcceptButton = (AppCompatButton) dialog.findViewById(R.id.btn_signup);
                    // if decline button is clicked, close the custom dialog
                    AcceptButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            emailEditText = (EditText)dialog.findViewById(R.id.editText_email);
                            passEditText = (EditText)dialog.findViewById(R.id.editText_password);

                            boolean isValidate=true;
                            final String email=emailEditText.getText().toString();
                            if (!isValidEmail(email)) {
                                emailEditText.setError("Invalid Email");
                                isValidate=false;
                            }
                            final String pass = passEditText.getText().toString();
                            if (!isValidPassword(pass)) {
                                passEditText.setError("Invalid Password");
                                isValidate=false;
                            }
                            if(isValidate){

                                String url=getString(R.string.ip_address).concat(getString(R.string.login)).concat(emailEditText.getText().toString()).concat(getString(R.string.inputpassword))
                                        .concat(passEditText.getText().toString());
                                new InvokeWebServiceForSignupLogin(getApplicationContext(),SignupActivity.this,2,passEditText.getText().toString()).execute(url);

                            }
                            else{
                                return;

                                /*Toast.makeText(SignupActivity.this, "Invalid Password", Toast.LENGTH_LONG).show();*/
                            }
                            dialog.dismiss();
                        }
                    });



                   /* Intent intent = new Intent(SignupActivity.this, PinActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    FragmentManager fragmentManager = SignupActivity.this.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    SignupActivity.this.startActivity(intent);
                    finish();*/


                }
            });
        }
   }
    public static boolean isValidEmail(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    // validating password with retype password
    public static boolean isValidPassword(String pass) {
        if (pass != null && pass.length() > 6) {
            return true;
        }
        return false;
    }
}

