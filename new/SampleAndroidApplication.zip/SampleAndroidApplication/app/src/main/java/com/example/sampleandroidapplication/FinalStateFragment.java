package com.example.sampleandroidapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.anton46.stepsview.StepsView;


import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 21-06-2018.
 */

public class FinalStateFragment extends Fragment {

    View v;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.step_wise_information, null);


        v.setFocusableInTouchMode(true);
        v.requestFocus();
        v.setOnKeyListener(new View.OnKeyListener() {
                               @Override
                               public boolean onKey(View view, int keyCode, KeyEvent keyEvent) {
                                   if (keyCode == KeyEvent.KEYCODE_BACK && keyEvent.getAction() == KeyEvent.ACTION_UP) {
                                       Log.i("working", "onKey Back listener is working!!!");
                                      Intent intent = new Intent(getActivity(), Dashboard.class);
                                       intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                                       startActivity(intent);
                                       getActivity().finish();
                                    /*   FragmentManager fm = getActivity().getSupportFragmentManager();
                                       for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                           fm.popBackStack();
                                       }
                                       Intent intent = new Intent(getActivity(), Dashboard.class);
                                       startActivity(intent);*/
                                   }
                                   return false;
                               }
                           });
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        Button redirectButton=(Button)v.findViewById(R.id.ok);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), Dashboard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                getActivity().finish();
            }
        });
/*        ViewPager pager = (ViewPager)v.findViewById(R.id.viewPager);
        pager.setAdapter(new StepWisePagerAdapter(getChildFragmentManager()));*/

       //Bind the step indicator to the adapter
        StepsView mStepsView = (StepsView)v. findViewById(R.id.stepsView);
        String[] stepWiseNames =  {"Select Matchs","Payment","Final"};

        mStepsView.setLabels(stepWiseNames)
                .setBarColorIndicator(getContext().getResources().getColor(R.color.orange))
                .setProgressColorIndicator(getContext().getResources().getColor(R.color.light_color))
                .setLabelColorIndicator(getContext().getResources().getColor(R.color.light_color))
                .setCompletedPosition(2)
                .drawView();


        redirectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), Dashboard.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                getActivity().finish();
            }
        });


        return v;
    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }

}

