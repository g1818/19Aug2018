package com.example.sampleandroidapplication.com.dtos;

/**
 * @author Guna.Sekhar
 *
 */
public class QuestionsDTO {

	public String getQuestionsID() {
		return questionsID;
	}

	public void setQuestionsID(String questionsID) {
		this.questionsID = questionsID;
	}

	private 	String matchQuestionsID;
	private 	String questionDesc;
	private 	String firstOption;
	private 	String secondOption;
	private 	String answers;
	private      String questionsID;
	
	
	public String getAnswers() {
		return answers;
	}
	public void setAnswers(String answers) {
		this.answers = answers;
	}
	
	public String getMatchQuestionsID() {
		return matchQuestionsID;
	}
	public void setMatchQuestionsID(String matchQuestionsID) {
		this.matchQuestionsID = matchQuestionsID;
	}
	public String getQuestionDesc() {
		return questionDesc;
	}
	public void setQuestionDesc(String questionDesc) {
		this.questionDesc = questionDesc;
	}
	public String getFirstOption() {
		return firstOption;
	}
	public void setFirstOption(String firstOption) {
		this.firstOption = firstOption;
	}
	public String getSecondOption() {
		return secondOption;
	}
	public void setSecondOption(String secondOption) {
		this.secondOption = secondOption;
	}
	
	

}
