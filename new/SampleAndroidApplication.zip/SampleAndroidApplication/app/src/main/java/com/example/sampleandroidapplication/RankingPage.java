package com.example.sampleandroidapplication;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.RankingfourAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class RankingPage extends Fragment {

    View v;
    ViewPager viewPager;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.ranking_page, null);
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        viewPager = (ViewPager) v.findViewById(R.id.viewpager);
        TabLayout sliding_tabs = (TabLayout) v.findViewById(R.id.sliding_tabs);
        List<String> rankingTabNames=new ArrayList<>();
        TextView textView=(TextView)v.findViewById(R.id.tabheading);
        textView.setText("Ranking");

        rankingTabNames.add("Batsmen");
        rankingTabNames.add("Bowler");
        rankingTabNames.add("AllRounder");
        rankingTabNames.add("Teams");
        RankingfourAdapter rankingPageAdapter=new RankingfourAdapter(getChildFragmentManager(),rankingTabNames);
        viewPager.setAdapter(rankingPageAdapter);
        sliding_tabs.setupWithViewPager(viewPager);


        return v;


    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }

}
