package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class AddToBankInformation extends Fragment {
    private EditText account;
    private EditText ifsc;
    View v;
     ProgressDialog progressDialog;
     String amount;
    List<String> banks;
    Spinner spinner;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.addtobank, null);
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        Bundle bundle=getArguments();
        amount=bundle.getString("amt");
         banks=new ArrayList<>();
        banks.add("ALLAHABAD BANK");
        banks.add("ANDHRA BANK");
        banks.add("BANK OF BARODA");
        banks.add("BANK OF INDIA");
        banks.add("BANK OF MAHARASHTRA");
        banks.add("CANARA BANK");
        banks.add("IDBI BANK LTD");
        banks.add("INDIAN BANK");
        banks.add("INDIAN OVERSEAS BANK");
        banks.add("PUNJAB NATIONAL BANK");
        banks.add("STATE BANK OF INDIA");
        banks.add("SYNDICATE BANK");
        banks.add("UCO BANK");
        banks.add("UNION BANK OF INDIA");
        banks.add("UNITED BANK OF INDIA");
        banks.add("VIJAYA BANK");
        spinner = (Spinner) v.findViewById(R.id.bank_name);
        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(v.getContext(), android.R.layout.simple_spinner_item, banks);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);

        account = (EditText)v.findViewById(R.id.editText_account);
        ifsc = (EditText)v.findViewById(R.id.editText_ifsc);
        AppCompatButton button=(AppCompatButton)v.findViewById(R.id.btn_submit);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Log.i("pass",account.getText().toString());
                Log.i("selectedItem",spinner.getSelectedItem().toString());
                boolean isValidate = true;
                if (!isValid(account.getText().toString())) {
                    account.setError("Enter valid account number");
                    isValidate = false;
                }
                final String pass = ifsc.getText().toString();
                if (!isValid(pass)) {
                    ifsc.setError("Enter valid ISFC Code");
                    isValidate = false;
                }
                if (isValidate) {
              try {
                String url = getString(R.string.ip_address).concat(getString(R.string.bankinfo));
                SharedPreferences settings = v.getContext().getSharedPreferences("MY_PREFS_NAME", 0);
                String userEmail = settings.getString("username", "abc");
                final String status = new InvokeWebServiceForBankInfo(userEmail, account.getText().toString(), ifsc.getText().toString(), spinner.getSelectedItem().toString().toString(), amount).execute(url).get();
                Intent intent = new Intent(view.getContext(), Dashboard.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("email", "abc");
                intent.putExtra("name", "abc");
    view.getContext().startActivity(intent);
    Toast.makeText(view.getContext(), "SucessFully Processed", Toast.LENGTH_LONG).show();
}
catch(Exception e){
    e.printStackTrace();
}

                }
            }
        });
       return v;
    }
    private boolean isValid(String pass) {
        Log.i("pass",pass);
        if (pass!="" && pass.length()>2) {
            return true;
        }
        return false;
    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }

}
class InvokeWebServiceForBankInfo extends AsyncTask<String, Void, String> {
    StringBuffer sb = new StringBuffer();
    String userName;
    String acNo;
    String ifsc;
    String bankName;
    String amount;

    InvokeWebServiceForBankInfo(String userName,String acNo,String ifsc,String bankName,String amount) {

        this.userName=userName;
        this.acNo=acNo;
        this.ifsc=ifsc;
        this.bankName=bankName;
        this.amount=amount;

    }

    @Override
    protected String doInBackground(String... strings) {

        try {
            JSONObject post_dict = new JSONObject();
            post_dict.put("EMAIL", userName);
            post_dict.put("CARD_NO", acNo);
            post_dict.put("BANK_NAME", bankName);
            post_dict.put("IFSC_CODE", ifsc);
            post_dict.put("AMOUNT", amount);

            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(strings[0]).openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST"); // here you are telling that it is a POST request, which can be changed into "PUT", "GET", "DELETE" etc.
            httpURLConnection.setRequestProperty("Content-Type", "application/json"); // here you are setting the `Content-Type` for the data you are sending which is `application/json`
            httpURLConnection.connect();

            DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
            wr.writeBytes(post_dict.toString());
            wr.flush();
            wr.close();
            int responseCode = httpURLConnection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(
                                httpURLConnection.getInputStream()));

                String line = "";

                while ((line = in.readLine()) != null) {

                    sb.append(line);
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
}


