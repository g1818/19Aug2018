package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class RankingDetails extends Fragment {

    ListViewAdapter listViewAdapter;
    ViewPager pager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Returning the layout file after inflating
        //Change R.layout.tab1 in you classes
        View v= inflater.inflate(R.layout.fragment_layout_ranking, container, false);

        pager = (ViewPager) v.findViewById(R.id.view_pager);
        TabLayout layout= (TabLayout) v.findViewById(R.id.tablayout);
        int  id=getArguments().getInt("value");

        List<String> name=new ArrayList<String>();
        name.add("test");
        name.add("odi");
        name.add("t20");

        BatsemFragment rankingPageAdapter=new BatsemFragment(getChildFragmentManager(),name,id);
        pager.setAdapter(rankingPageAdapter);
        layout.setupWithViewPager(pager);
    /*    pager.setAdapter(new FragmentStatePagerAdapter(getChildFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                if(position==0){

                    return new TESTFragmentBatsmen();
                }else if(position == 1 ){
                    return new ODIFragmentBatsmen();
                }
                else {

                     return new T20FragmentBatsmen();
                }

            }

            @Override
            public int getCount() {
                return 3;
            }
        });*/
        pager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(layout));
        layout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                pager.setCurrentItem(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
            }
        });


        return v;
    }

}
