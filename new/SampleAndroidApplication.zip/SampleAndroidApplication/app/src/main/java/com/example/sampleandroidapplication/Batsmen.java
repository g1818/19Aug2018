package com.example.sampleandroidapplication;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class Batsmen {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }

    public String getI() {
        return i;
    }

    public void setI(String i) {
        this.i = i;
    }

    public String getR() {
        return r;
    }

    public void setR(String r) {
        this.r = r;
    }

    public String getAvg() {
        return avg;
    }

    public void setAvg(String avg) {
        this.avg = avg;
    }

    String name;
    String m;
    String i;
    String r;
    String avg;

}
