package com.example.sampleandroidapplication;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class RankingPageAdapter extends FragmentStatePagerAdapter
{

      List<String> rankingTabName=new ArrayList<>();
      public RankingPageAdapter(FragmentManager fm,List<String> rankingTabName){

          super(fm);
          this.rankingTabName=rankingTabName;
      }


    @Override
    public Fragment getItem(int position) {
        RankingDetails tab1=new RankingDetails();
        if(rankingTabName.get(position).equalsIgnoreCase("Batting")){

            return new RecordBatting();

        }
        else if(rankingTabName.get(position).equalsIgnoreCase("Bowling")){

            return new RecordBowling();


        }
        return  tab1;
    }

    @Override
    public int getCount() {
        return rankingTabName.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        if (rankingTabName != null) {
            return rankingTabName.get(position);
        }
        return null;
    }

}
