package com.example.sampleandroidapplication;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.GridLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class MostRunsArrayAdaopter extends ArrayAdapter<Batsmen> {

    Context context;
    List<Batsmen> user;


    public MostRunsArrayAdaopter(Context context, List<Batsmen> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }
    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.test__batsmenmost_runs_listview, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label1);
        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        TextView textView3 = (TextView) rowView.findViewById(R.id.label3);
        TextView textView4 = (TextView) rowView.findViewById(R.id.label4);
        TextView textView5 = (TextView) rowView.findViewById(R.id.label5);
        textView.setText(user.get(position).getName());
        textView2.setText(user.get(position).getM());
        textView3.setText(user.get(position).getI());
        textView4.setText(user.get(position).getR());
        textView5.setText(user.get(position).getAvg());
        TableRow.LayoutParams lc$param = new TableRow.LayoutParams();
        lc$param.height = GridLayout.LayoutParams.WRAP_CONTENT;
        lc$param.width = dpToPx(80);
        textView3.setLayoutParams(lc$param);
        textView.setLayoutParams(lc$param);
        textView2.setLayoutParams(lc$param);
        textView4.setLayoutParams(lc$param);
        textView4.setLayoutParams(lc$param);

        if(position==0){

            textView.setBackgroundResource(R.color.light_color);
            textView2.setBackgroundResource(R.color.light_color);
            textView3.setBackgroundResource(R.color.light_color);
            textView4.setBackgroundResource(R.color.light_color);
            textView5.setBackgroundResource(R.color.light_color);

        }


        return rowView;
    }

}