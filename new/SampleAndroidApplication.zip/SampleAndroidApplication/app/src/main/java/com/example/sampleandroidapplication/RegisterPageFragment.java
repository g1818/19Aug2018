package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.MatchArgumentsDTO;
import com.example.sampleandroidapplication.com.dtos.MatchesDTO;

import java.util.List;

/**
 * Created by Ashwini.R on 30-05-2018.
 */

public class RegisterPageFragment extends Fragment {

    View v;
    List<MatchArgumentsDTO> matchArgumentsDTOS;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.registered_match_listview_tab, container, false);
        Bundle args = getArguments();
        matchArgumentsDTOS =  args.getParcelableArrayList("value");
        TextView textView = (TextView) v.findViewById(R.id.label1);
        TextView textView2 = (TextView) v.findViewById(R.id.label2);
        TextView textView3 = (TextView) v.findViewById(R.id.label3);
        TextView textView4 = (TextView) v.findViewById(R.id.label4);
        TextView textView5 = (TextView) v.findViewById(R.id.label5);
        TextView textView6 = (TextView) v.findViewById(R.id.label6);
        TextView textView7 = (TextView) v.findViewById(R.id.label7);
        TextView textView8 = (TextView) v.findViewById(R.id.label8);

        if(matchArgumentsDTOS.size()>0) {
            if(matchArgumentsDTOS.get(0) !=null) {

                textView.setText(matchArgumentsDTOS.get(0).getArgumentDesc());
            textView2.setText(matchArgumentsDTOS.get(0).getArgumentValue());
        }
        }

        if(matchArgumentsDTOS.size()>1) {
        if(matchArgumentsDTOS.get(1) !=null) {
            textView3.setText(matchArgumentsDTOS.get(1).getArgumentDesc());
            textView4.setText(matchArgumentsDTOS.get(1).getArgumentValue());

        }
        }
        if(matchArgumentsDTOS.size()>2) {
        if(matchArgumentsDTOS.get(2) !=null) {

            textView5.setText(matchArgumentsDTOS.get(2).getArgumentDesc());
            textView6.setText(matchArgumentsDTOS.get(2).getArgumentValue());
        }        }
        if(matchArgumentsDTOS.size()>3) {
        if(matchArgumentsDTOS.get(3) != null) {
            textView7.setText(matchArgumentsDTOS.get(3).getArgumentDesc());
            textView8.setText(matchArgumentsDTOS.get(3).getArgumentValue());

        }}


        return v;
    }

}
