package com.example.sampleandroidapplication.com.dtos;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import java.io.Serializable;

/**
 * Created by Guna Sekhar on 26-06-2018.
 */

public class MatchArgumentsDTO  implements Serializable, Comparable<SeriesDTO>,Parcelable {


	
    private 	String matchArgumentId;
    private 	String argumentDesc;
    private     String argumentValue;
    private     String matcheid;
    
    
	public String getMatchArgumentId() {
		return matchArgumentId;
	}
	public void setMatchArgumentId(String matchArgumentId) {
		this.matchArgumentId = matchArgumentId;
	}
	public String getArgumentDesc() {
		return argumentDesc;
	}
	public void setArgumentDesc(String argumentDesc) {
		this.argumentDesc = argumentDesc;
	}
	public String getArgumentValue() {
		return argumentValue;
	}
	public void setArgumentValue(String argumentValue) {
		this.argumentValue = argumentValue;
	}
	public String getMatcheid() {
		return matcheid;
	}
	public void setMatcheid(String matcheid) {
		this.matcheid = matcheid;
	}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel parcel, int i) {

	}

	@Override
	public int compareTo(@NonNull SeriesDTO seriesDTO) {
		return 0;
	}
}
