package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.Log;
import android.util.SparseArray;

import com.example.sampleandroidapplication.com.dtos.MatchArgumentsDTO;
import com.example.sampleandroidapplication.com.dtos.MatchesDTO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by Ashwini.R on 14-06-2018.
 */

public class RegisteredMatchFragmentAdapter extends FragmentStatePagerAdapter {
    Map<Integer, List<MatchArgumentsDTO>> map;
    SparseArray<Fragment> registeredFragments = new SparseArray<Fragment>();


    public RegisteredMatchFragmentAdapter(FragmentManager fm,  Map<Integer, List<MatchArgumentsDTO>> map) {
        super(fm);
       this.map=map;

    }

    @Override
    public int getCount() {
        if ( map != null) {
            Log.i("Size",String.valueOf(map.get(0)));
            return map.size();

        }
        return 0;
    }


    @Override
    public Fragment getItem(int position) {
        Bundle arguments = new Bundle();
        Log.i("position",String.valueOf(position));
        arguments.putParcelableArrayList("value", (ArrayList<? extends Parcelable>) map.get(position));
        RegisterPageFragment fragment = new RegisterPageFragment();
        fragment.setArguments(arguments);
        return fragment;
    }

}