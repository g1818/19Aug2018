package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.andrognito.pinlockview.PinLockView;
import com.example.sampleandroidapplication.com.dtos.ContestDTO;
import com.example.sampleandroidapplication.com.dtos.QuestionAnswerPayment;
import com.example.sampleandroidapplication.com.dtos.QuestionsDTO;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Created by Ashwini.R on 21-06-2018.
 */

public class CurrentMatchFragment extends Fragment {

    View v;
    static int i = 0;
    String matchId;
    SharedPreferences settings;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.current_matchs, null);
        settings = getActivity().getSharedPreferences("MY_PREFS_NAME", 0);
        Bundle bundle=getArguments();
        matchId=bundle.getString("matchId");
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });



       String email=settings.getString("username","abc");
       String url=getString(R.string.ip_address).concat(getString(R.string.current_contest)).concat(email).concat(getString(R.string.match_id).concat(matchId));

        Log.i("url",url);
        new InvokeWebServiceForCurrentMatch(v,getActivity(),matchId).execute(url);


        return v;

    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}
class InvokeWebServiceForCurrentMatch extends AsyncTask<String,Void,String> {

    List<ContestDTO> contestDTOList;
    CurrentMatchsArrayAdapter listViewArrayAdapter;
    View view;
    ListView listView;
    private ProgressDialog progressDialog;
    LinearLayout linearLayout;
    FragmentActivity fragmentActivity;
    String matchId;
    InvokeWebServiceForCurrentMatch(View v, FragmentActivity fragmentActivity,String matchId) {
        view = v;
        this.fragmentActivity=fragmentActivity;
        this.matchId=matchId;

    }

    @Override
    protected void onPreExecute() {
        progressDialog = ProgressDialog.show(view.getContext(), "Loading", "Please wait a moment!");
    }

    @Override
    protected String doInBackground(String... strings) {

        StringBuffer buffer = new StringBuffer();
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line = "";
            while ((line = bf.readLine()) != null) {
                buffer.append(line);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return buffer.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        listView= (ListView)view.findViewById(R.id.current_match_list);
        linearLayout=(LinearLayout)view.findViewById(R.id.emptydata);
        linearLayout.setVisibility(View.GONE);
        try {
            if (progressDialog.isShowing()) progressDialog.dismiss();
            ObjectMapper mapperObject = new ObjectMapper();

            Log.i("res",s);
            contestDTOList = mapperObject.readValue(s, mapperObject.getTypeFactory().constructCollectionType(List.class, ContestDTO.class));
            System.out.println("inside postexecute=" + contestDTOList.size());

            if (contestDTOList != null && !contestDTOList.isEmpty()) {
                listView.setVisibility(View.VISIBLE);
                listViewArrayAdapter=new CurrentMatchsArrayAdapter(view.getContext(),contestDTOList);

                listView.setAdapter(listViewArrayAdapter);

            }
            else{
                listView.setVisibility(View.GONE);
                linearLayout.setVisibility(View.VISIBLE);
                return;
            }
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    FragmentManager fragmentManager = fragmentActivity.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    RegisteredMatchFragment registeredMatchFragment = new RegisteredMatchFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("matchId", matchId);
                    bundle.putString("contestId", contestDTOList.get(i).getContestId());
                    bundle.putString("contestCountId", String.valueOf(contestDTOList.get(i).getContestCount()));
                    registeredMatchFragment.setArguments(bundle);
                    fragmentTransaction.replace(R.id.fragment_container, registeredMatchFragment);
                    fragmentTransaction.addToBackStack(null);
                    fragmentTransaction.commit();
                }
            });
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

}


