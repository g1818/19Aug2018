package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.anton46.stepsview.StepsView;
import com.example.sampleandroidapplication.com.dtos.ContestDTO;
import com.example.sampleandroidapplication.com.dtos.QuestionAnswerPayment;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.paytm.pgsdk.PaytmClientCertificate;
import com.paytm.pgsdk.PaytmMerchant;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by Ashwini.R on 25-06-2018.
 */

public class Payment extends Fragment {

    View v;
    AppCompatButton next;
    TextView textView;
    SharedPreferences settings;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.slect_matchs, null);
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        final String url=getString(R.string.ip_address).concat(getString(R.string.add_answers));
        final String pYMENTurl = getString(R.string.ip_address).concat("match/generateChecksum");
        next=(AppCompatButton)v.findViewById(R.id.next);
        Bundle args = getArguments();
        final List<QuestionAnswerPayment> questionAnswerPaymentList = args.getParcelableArrayList("questionList");
        textView=(TextView)v.findViewById(R.id.heading);
        settings = this.getActivity().getSharedPreferences("MY_PREFS_NAME", 0);
        final String  userEmail=settings.getString("username","abc");
        final  String amount=args.getString("amount","0");
        textView.setText("Payment");
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                   // boolean status = new InvokeWebServices(v, getActivity(), amount).execute(pYMENTurl,userEmail).get();
                    if (true) {
                        for (QuestionAnswerPayment questionAnswerPayment : questionAnswerPaymentList) {
                            questionAnswerPayment.setPaymentStatus("Y");
                            questionAnswerPayment.setUseremail(userEmail);
                        }
                        new AsyncTSendData(v, getActivity(), questionAnswerPaymentList).execute(url);
                    } else {

                        Toast.makeText(getActivity(), "Payment Error!!", Toast.LENGTH_LONG).show();
                        Intent intent = new Intent(getActivity(), Dashboard.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        getActivity().finish();

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                // new AsyncTSendData(v,getActivity(),questionAnswerPaymentList).execute(url);

              /*  FragmentManager fragmentManager = getFragmentManager();
                QuestionAnswersFragment questionAnswersFragment=new QuestionAnswersFragment();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, questionAnswersFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();*/
            }
        });
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
/*        ViewPager pager = (ViewPager)v.findViewById(R.id.viewPager);
        pager.setAdapter(new StepWisePagerAdapter(getChildFragmentManager()));*/

        //Bind the step indicator to the adapter
        StepsView mStepsView = (StepsView)v. findViewById(R.id.stepsView);
        String[] stepWiseNames =  {"Select Matchs","Payment","Final"};

        mStepsView.setLabels(stepWiseNames)
                .setBarColorIndicator(getContext().getResources().getColor(R.color.orange))
                .setProgressColorIndicator(getContext().getResources().getColor(R.color.light_color))
                .setLabelColorIndicator(getContext().getResources().getColor(R.color.light_color))
                .setCompletedPosition(1)
                .drawView();

        return v;
    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}
class InvokeWebServices extends AsyncTask<String, Void, Boolean> {
    StringBuffer sb = new StringBuffer();


    String callbackurl = "https://securegw-stage.paytm.in/theia/paytmCallback?ORDER_ID=";

    View v;
    FragmentActivity fragmentActivity;
    String amount;
    String orderId;

    InvokeWebServices(View v, FragmentActivity fragmentActivity, String amount) {
        this.v = v;
        this.fragmentActivity = fragmentActivity;
        this.amount = amount;
    }
    boolean status=false;

    @Override
    protected Boolean doInBackground(String... strings) {
        status=false;
        orderId=getSaltString();
        try {
            Log.i("amount",amount);
            JSONObject post_dict = new JSONObject();
            post_dict.put("ORDER_ID", orderId); //cll a function
            post_dict.put("MID", "retail52735650586733");
            post_dict.put("CUST_ID", strings[1]); //call a function
            post_dict.put("CHANNEL_ID", "WAP");
            post_dict.put("INDUSTRY_TYPE_ID", "Retail");
            post_dict.put("WEBSITE", "APPSTAGING");
            post_dict.put("TXN_AMOUNT", amount);
            post_dict.put("CALLBACK_URL", callbackurl + orderId);
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(strings[0]).openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST"); // here you are telling that it is a POST request, which can be changed into "PUT", "GET", "DELETE" etc.
            httpURLConnection.setRequestProperty("Content-Type", "application/json"); // here you are setting the `Content-Type` for the data you are sending which is `application/json`
            httpURLConnection.connect();

            DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
            wr.writeBytes(post_dict.toString());
            wr.flush();
            wr.close();
            int responseCode = httpURLConnection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {

                BufferedReader in = new BufferedReader(
                        new InputStreamReader(
                                httpURLConnection.getInputStream()));

                String line = "";

                while ((line = in.readLine()) != null) {

                    sb.append(line);
                    break;
                }
                if(sb.toString()==null){
                    return false;
                }else {
                    status=true;
                }

                in.close();
                Map<String, String> paramMap = new HashMap<String, String>();

                //these are mandatory parameters

                paramMap.put("ORDER_ID", orderId);
                //MID provided by paytm
                paramMap.put("MID", "retail52735650586733");
                paramMap.put("CUST_ID", strings[1]);
                paramMap.put("CHANNEL_ID", "WAP");
                paramMap.put("INDUSTRY_TYPE_ID", "Retail");
                paramMap.put("WEBSITE", "APPSTAGING");
                paramMap.put("TXN_AMOUNT", amount);
                //
                paramMap.put("CALLBACK_URL",
                        callbackurl + orderId);
                Log.i("Checksumhash", sb.toString());
                paramMap.put("CHECKSUMHASH", sb.toString());
                PaytmPGService Service = PaytmPGService.getStagingService();
                PaytmOrder order = new PaytmOrder(paramMap);
                PaytmMerchant merchant = new PaytmMerchant(
                        "url", "https://securegw-stage.paytm.in/theia/processTransaction");

                PaytmClientCertificate certificate = null;

                Service.initialize(order, certificate);

                Service.startPaymentTransaction(fragmentActivity, true, true, new PaytmPaymentTransactionCallback() {

                    @Override
                    public void onTransactionResponse(Bundle inResponse) {

                        Log.d("LOG", "Payment Transaction : " + inResponse);
                        String response=inResponse.getString("RESPMSG");
                        if (response.equals("Txn Successful."))
                        {
                            status=true;

                        }else {
                            status=false;

                        }

                    }

                    @Override
                    public void networkNotAvailable() {
                        status=false;
                    }

                    @Override
                    public void clientAuthenticationFailed(String inErrorMessage) {
                        status=false;
                    }

                    @Override
                    public void someUIErrorOccurred(String inErrorMessage) {
                        status=false;
                    }

                    @Override
                    public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String inFailingUrl) {
                        status=false;
                    }

                    @Override
                    public void onBackPressedCancelTransaction() {
                        status=false;
                    }

                    @Override
                    public void onTransactionCancel(String inErrorMessage, Bundle inResponse) {
                        status=false;
                        return;
                    }

                });
            }
            return status;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }
   public String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 16) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;
    }

}
class AsyncTSendData extends AsyncTask<String,Void,String> {

    List<QuestionAnswerPayment> questionAnswerPaymentList=new ArrayList<>();
    View view;
    private ProgressDialog progressDialog;
    FragmentActivity fragmentActivity;
    AsyncTSendData(View v, FragmentActivity fragmentActivity,List<QuestionAnswerPayment> questionAnswerPaymentList) {

        view = v;
        this.fragmentActivity=fragmentActivity;
        this.questionAnswerPaymentList=questionAnswerPaymentList;

    }

    @Override
    protected void onPreExecute() {

        progressDialog = ProgressDialog.show(view.getContext(), "Loading", "Please wait a moment!");
    }



    @Override
    protected String doInBackground(String... strings) {
        try {
            URL url = new URL(strings[0]); //Enter URL here
            HttpURLConnection httpURLConnection = (HttpURLConnection)url.openConnection();
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setRequestMethod("POST"); // here you are telling that it is a POST request, which can be changed into "PUT", "GET", "DELETE" etc.
            httpURLConnection.setRequestProperty("Content-Type", "application/json"); // here you are setting the `Content-Type` for the data you are sending which is `application/json`
            httpURLConnection.connect();

            Gson gson = new Gson();
            Type type = new TypeToken<List<QuestionAnswerPayment>>() {}.getType();
            String json = gson.toJson(questionAnswerPaymentList, type);

/*
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("para_1", questionAnswerPaymentList);*/

            DataOutputStream wr = new DataOutputStream(httpURLConnection.getOutputStream());
            wr.writeBytes(json);
            wr.flush();
            wr.close();
            int responseCode=httpURLConnection.getResponseCode();

            if (responseCode == HttpURLConnection.HTTP_OK) {

                BufferedReader in=new BufferedReader(
                        new InputStreamReader(
                                httpURLConnection.getInputStream()));
                StringBuffer sb = new StringBuffer("");
                String line="";

                while((line = in.readLine()) != null) {

                    sb.append(line);
                    break;
                }

                in.close();
                return sb.toString();

            }
            else {
                return new String("false : "+responseCode);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
    @Override
    protected void onPostExecute(String s) {

        if (progressDialog.isShowing()) progressDialog.dismiss();

        if(s.equalsIgnoreCase("true")){
            FragmentManager fragmentManager = fragmentActivity.getSupportFragmentManager();
            FinalStateFragment payment=new FinalStateFragment();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fragment_container, payment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        }
        else{

        }

        Log.i("result",s);


    }

}