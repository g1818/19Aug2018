package com.example.sampleandroidapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by Ashwini.R on 31-05-2018.
 */

public class ListViewRecordBattingArrayAdapter extends ArrayAdapter<String> {

    Context context;
    List<String> user;


    public ListViewRecordBattingArrayAdapter(Context context, List<String> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.activity_listview, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label1);
        textView.setText(user.get(position));
        return rowView;
    }

}
