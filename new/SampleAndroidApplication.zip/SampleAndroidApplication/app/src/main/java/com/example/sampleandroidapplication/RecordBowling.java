package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class RecordBowling extends Fragment {

    ListViewRecordBattingArrayAdapter listViewAdapter;
    ViewPager pager;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Returning the layout file after inflating
        //Change R.layout.tab1 in you classes
        View v = inflater.inflate(R.layout.test_fragment_batsmen, container, false);

        List<String> bowlingList = new ArrayList<>();
        bowlingList.add("Most Wickets");
        bowlingList.add("Best Bowling Average");
        bowlingList.add("Most 5 Wickets Hauls");
        bowlingList.add("Best Economy");
        bowlingList.add("Best Bowling Strike Rate");
        bowlingList.add("Best Bowling");

        listViewAdapter = new ListViewRecordBattingArrayAdapter(v.getContext(), bowlingList);

        ListView listView = (ListView) v.findViewById(R.id.tabList);
        listView.setAdapter(listViewAdapter);

        return v;


    }

}

