package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.sampleandroidapplication.com.dtos.SeriesDTO;
import com.example.sampleandroidapplication.com.dtos.TeamsDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Guna.Sekhar on 6/13/2018.
 */

public class BrowseTeamDetails extends Fragment {

    int id;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Returning the layout file after inflating
        //Change R.layout.tab1 in you classes
        View v= inflater.inflate(R.layout.test_fragment_batsmen, container, false);

        Bundle bundle=new Bundle();
        int  id=getArguments().getInt("value");
        String url=getString(R.string.ip_address).concat(getString(R.string.teamdetails).concat(String.valueOf(id)));

        Log.i("url",url);
        new InvokeWebServiceBrowseTeam(v,getActivity()).execute(url);

        return v;
    }

}

class InvokeWebServiceBrowseTeam extends AsyncTask<String,Void,String> {

    View view;
    List<TeamsDTO> rankDTOList = new ArrayList<>();
    private ProgressDialog progressDialog;
    FragmentActivity fragmentActivity;
    InvokeWebServiceBrowseTeam(View v, FragmentActivity fragmentActivity) {

        view = v;
        this.fragmentActivity=fragmentActivity;

    }

    @Override
    protected void onPreExecute() {

        progressDialog = ProgressDialog.show(view.getContext(), "Loading", "Please wait a moment!");
    }

    @Override
    protected String doInBackground(String... strings) {

        StringBuffer buffer = new StringBuffer();
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line = "";
            while ((line = bf.readLine()) != null) {
                buffer.append(line);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return buffer.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        try {
            if (progressDialog.isShowing()) progressDialog.dismiss();
            ObjectMapper mapperObject = new ObjectMapper();

            Log.i("res",s);
            rankDTOList = mapperObject.readValue(s, mapperObject.getTypeFactory().constructCollectionType(List.class, TeamsDTO.class));
            System.out.println("inside postexecute=" + rankDTOList.size());

            if (rankDTOList != null || !rankDTOList.isEmpty()) {


                ListView listView = (ListView) view.findViewById(R.id.tabList);

                BrowseTeamArrayAdapter testBatsmenArrayAdaopter = new BrowseTeamArrayAdapter(view.getContext(), rankDTOList);

                listView.setAdapter(testBatsmenArrayAdaopter);








            }
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

}


