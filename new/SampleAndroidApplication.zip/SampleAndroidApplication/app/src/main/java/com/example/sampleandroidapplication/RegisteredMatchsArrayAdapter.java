package com.example.sampleandroidapplication;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.ContestDTO;
import com.example.sampleandroidapplication.com.dtos.UserQuestionAnswerDTO;

import java.util.List;

/**
 * Created by Ashwini.R on 31-05-2018.
 */

public class RegisteredMatchsArrayAdapter extends ArrayAdapter<UserQuestionAnswerDTO> {

    Context context;
    List<UserQuestionAnswerDTO> user;


    public RegisteredMatchsArrayAdapter(Context context, List<UserQuestionAnswerDTO> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.registered_players_listview, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label1);
        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        TextView textView3=(TextView)rowView.findViewById(R.id.label3);
        Button button=(Button)rowView.findViewById(R.id.points);
        textView.setText(String.valueOf(position+1).concat(". ").concat(user.get(position).getQuestionDesc().trim()));
        textView2.setText("User Ans: ".concat(user.get(position).getUserAnswers().trim()));
        textView3.setText("Correct Ans: ".concat(user.get(position).getCurrentAnswers().trim()));
        if(user.get(position).getAnswerPoint()== null){
            button.setText("NA");
        }
        else if(Integer.parseInt(user.get(position).getAnswerPoint())>0){
            button.setText("+ ".concat(user.get(position).getAnswerPoint()));
            button.setBackgroundColor(rowView.getResources().getColor(R.color.green));

        }
        else {
            button.setText("- ".concat(user.get(position).getAnswerPoint()));
            button.setBackgroundColor(rowView.getResources().getColor(R.color.red));
        }
        return rowView;
    }

}
