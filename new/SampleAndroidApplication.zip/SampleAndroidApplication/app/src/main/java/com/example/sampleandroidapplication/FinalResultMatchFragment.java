package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.sampleandroidapplication.com.dtos.MatchArgumentsDTO;
import com.example.sampleandroidapplication.com.dtos.MatchWinDTO;
import com.example.sampleandroidapplication.com.dtos.UserQuestionAnswerDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import me.relex.circleindicator.CircleIndicator;

/**
 * Created by Ashwini.R on 21-06-2018.
 */

public class FinalResultMatchFragment extends Fragment {

    View v;
    static int i = 0;

    String matchId;
    String contestId;
    String contestCountID;
    SharedPreferences settings;
    String email;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.matchs, null);
        settings = getActivity().getSharedPreferences("MY_PREFS_NAME", 0);
        email = settings.getString("username", "abc");
        Bundle bundle = getArguments();
        matchId = bundle.getString("matchId");
        contestId = bundle.getString("contestId");
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });


        Log.i("matchId", matchId);
        Log.i("matchId", contestId);


        String url = getString(R.string.ip_address).concat(getString(R.string.resultcontest)).concat(matchId).concat(getString(R.string.contestId)).concat(contestId);

        Log.i("url", url);
        new InvokeWebServiceForFinalRegtisteredMatch(v, getActivity()).execute(url);


        return v;

    }

    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}
    class InvokeWebServiceForFinalRegtisteredMatch extends AsyncTask<String,Void,String> {

        List<MatchWinDTO> userQuestionAnswerDTOList;
        ResultsMatchsArrayAdapter listViewArrayAdapter;
        View view;
        ListView listView;
        private ProgressDialog progressDialog;
        FragmentActivity fragmentActivity;
        private static ViewPager mPager;
        InvokeWebServiceForFinalRegtisteredMatch(View v, FragmentActivity fragmentActivity) {
            view = v;
            this.fragmentActivity=fragmentActivity;

        }

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(view.getContext(), "Loading", "Please wait a moment!");
        }

        @Override
        protected String doInBackground(String... strings) {

            StringBuffer buffer = new StringBuffer();
            try {
                URL url = new URL(strings[0]);
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                con.connect();
                BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));

                String line = "";
                while ((line = bf.readLine()) != null) {
                    buffer.append(line);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return buffer.toString();
        }

        @Override
        protected void onPostExecute(String s) {

            try {
                if (progressDialog.isShowing()) progressDialog.dismiss();
                ObjectMapper mapperObject = new ObjectMapper();


                Log.i("res",s);
                userQuestionAnswerDTOList = mapperObject.readValue(s, mapperObject.getTypeFactory().constructCollectionType(List.class, MatchWinDTO.class));
                System.out.println("inside postexecute=" + userQuestionAnswerDTOList.size());

                if (userQuestionAnswerDTOList != null && !userQuestionAnswerDTOList.isEmpty()) {

                    listViewArrayAdapter=new ResultsMatchsArrayAdapter(view.getContext(),userQuestionAnswerDTOList);
                    listView= (ListView)view.findViewById(R.id.current_match_list);
                    listView.setAdapter(listViewArrayAdapter);

                }
                else{
                    return;
                }
            } catch (Exception e) {

                e.printStackTrace();
            }

        }

    }





