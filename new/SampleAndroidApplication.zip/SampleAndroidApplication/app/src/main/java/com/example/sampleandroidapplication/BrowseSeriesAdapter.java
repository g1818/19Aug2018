package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Guna.Sekhar on 6/13/2018.
 */

public class BrowseSeriesAdapter extends FragmentStatePagerAdapter
{
    List<String> rankingTabName=new ArrayList<>();
    public BrowseSeriesAdapter(FragmentManager fm, List<String> rankingTabName){

        super(fm);
        this.rankingTabName=rankingTabName;
    }
    @Override
    public Fragment getItem(int position) {
        Bundle bundle=new Bundle();
        int value=0;
        if(rankingTabName.get(position).equalsIgnoreCase("international")){

            value=1;
        }

        else if(rankingTabName.get(position).equalsIgnoreCase("t20 leagues")){

            value=2;
        }
        else if(rankingTabName.get(position).equalsIgnoreCase("domestic")){

            value=3;
        }
        else{
            value=4;
        }
        bundle.putInt("value",value);
        BrowseSeriesDetails tab1=new BrowseSeriesDetails();
        tab1.setArguments(bundle);

        return  tab1;
    }

    @Override
    public int getCount() {
        return rankingTabName.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        if (rankingTabName != null) {
            return rankingTabName.get(position);
        }
        return null;
    }

}
