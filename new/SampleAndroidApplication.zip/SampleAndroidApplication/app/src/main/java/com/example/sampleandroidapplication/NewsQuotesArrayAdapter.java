package com.example.sampleandroidapplication;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.NewsDTO;
import com.example.sampleandroidapplication.com.dtos.PlayersDTO;

import java.util.List;

/**
 * Created by Guna.Sekhar on 6/13/2018.
 */

public class NewsQuotesArrayAdapter extends ArrayAdapter<NewsDTO> {

    Context context;
    List<NewsDTO> user;


    public NewsQuotesArrayAdapter(Context context, List<NewsDTO> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }
    public int dpToPx(int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.news_listview, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label1);
        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        textView.setText(user.get(position).getNewsName());
        textView2.setText(user.get(position).getNewsDesc());

        return rowView;
    }

}