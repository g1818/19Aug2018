package com.example.sampleandroidapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.sampleandroidapplication.com.dtos.MatchesDTO;

import java.text.SimpleDateFormat;
import java.util.List;

/**
 * Created by Guna.Sekhar on 6/14/2018.
 */

public class MatchesArrayAdapter extends ArrayAdapter<MatchesDTO> {

    Context context;
    List<MatchesDTO> user;


    public MatchesArrayAdapter(Context context, List<MatchesDTO> values) {
        super(context, -1, values);
        this.context = context;
        this.user = values;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.activity_listview_matchs_tab, parent, false);
        TextView textView = (TextView) rowView.findViewById(R.id.label1);

        SimpleDateFormat formater = new SimpleDateFormat("dd-MMM-yyyy");
        String format = formater.format(user.get(position).getStartDate());
        String format1 = formater.format(user.get(position).getEnd_date());
        textView.setText(format.concat(" to ").concat(format1));


        TextView textView1 = (TextView) rowView.findViewById(R.id.label7);
        textView1.setText(user.get(position).getMatchcomment().concat(" In").concat(user.get(position).getVenue()));


        TextView textView2 = (TextView) rowView.findViewById(R.id.label2);
        textView2.setText(user.get(position).getFirstTeam());


        TextView textView3 = (TextView) rowView.findViewById(R.id.label3);
        textView3.setText(user.get(position).getFirstteamscore());

        TextView textView4 = (TextView) rowView.findViewById(R.id.label4);
        textView4.setText(user.get(position).getSecondTeam());

        TextView textView5 = (TextView) rowView.findViewById(R.id.label5);
        textView5.setText(user.get(position).getSecondteamscore());

        TextView textView6 = (TextView) rowView.findViewById(R.id.label6);
        textView6.setText(user.get(position).getResultcomment());


        return rowView;
    }

}
