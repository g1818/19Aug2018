package com.example.sampleandroidapplication.com.dtos;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.io.Serializable;
import java.util.Date;


public class SeriesDTO implements Serializable, Comparable<SeriesDTO>,Parcelable {
	public int getSeriesId() {
		return seriesId;
	}

	public void setSeriesId(int seriesId) {
		this.seriesId = seriesId;
	}

	private 	String seriesName;

	@JsonDeserialize(using=CustomerDateAndTimeDeserialize.class)
	private Date startDate;

	@JsonDeserialize(using=CustomerDateAndTimeDeserialize.class)
	private 	Date end_date;

	private     int seriesId;
	
	public String getSeriesName() {
		return seriesName;
	}
	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}
	public Date getStartDate() {
		return startDate;
	}

	@JsonDeserialize(using=CustomerDateAndTimeDeserialize.class)
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEnd_date() {
		return end_date;
	}

	@JsonDeserialize(using=CustomerDateAndTimeDeserialize.class)
	public void setEnd_date(Date end_date) {
		this.end_date = end_date;
	}


	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel parcel, int i) {

	}

	@Override
	public int compareTo(@NonNull SeriesDTO seriesDTO) {
		return 0;
	}
}
