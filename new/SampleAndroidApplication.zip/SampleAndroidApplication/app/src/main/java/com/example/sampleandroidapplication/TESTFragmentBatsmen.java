package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.example.sampleandroidapplication.com.dtos.RankDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 04-06-2018.
 */

public class TESTFragmentBatsmen extends Fragment {

    View v;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

       v = inflater.inflate(R.layout.test_fragment_batsmen, container, false);

        int  mainTabid=getArguments().getInt("mainTabId");
        int  innerTabId=getArguments().getInt("innerTabId");
        Log.i("Main Tab Id",String.valueOf(mainTabid));
        Log.i("Inner Tab Id",String.valueOf(innerTabId));

        if(mainTabid != 4){
            String url = getString(R.string.ip_address).concat(getString(R.string.ranking_with_player_role)).concat(String.valueOf(mainTabid)).concat(getString(R.string.matchType)).concat(String.valueOf(innerTabId));
            new InvokeWebServiceRanking(v,0).execute(url);
        }
        else{

            String url=getString(R.string.ip_address).concat(getString(R.string.temRank)).concat(String.valueOf(innerTabId));
            new InvokeWebServiceRanking(v,1).execute(url);
        }

    /*  listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {


            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                String entry = (String) adapterView.getItemAtPosition(i);
                Log.i("Item Selected",entry);
                FragmentManager fragmentManager = getFragmentManager();
                ListViewFragment listViewFragment=new ListViewFragment();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.fragment_container, listViewFragment);
                fragmentTransaction.addToBackStack(null);
                fragmentTransaction.commit();
            }
        });
*/
        return v;
    }

}

class InvokeWebServiceRanking extends AsyncTask<String,Void,String> {

    View view;
    List<RankDTO> rankDTOList = new ArrayList<>();
    private ProgressDialog progressDialog;
    int id;

    InvokeWebServiceRanking(View v,int id) {

        view = v;
        this.id=id;
    }

    @Override
    protected void onPreExecute() {

        progressDialog = ProgressDialog.show(view.getContext(), "Loading", "Please wait a moment!");
    }

    @Override
    protected String doInBackground(String... strings) {

        StringBuffer buffer = new StringBuffer();
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line = "";
            while ((line = bf.readLine()) != null) {
                buffer.append(line);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return buffer.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        try {
            if (progressDialog.isShowing()) progressDialog.dismiss();
            ObjectMapper mapperObject = new ObjectMapper();

            Log.i("res",s);
            rankDTOList = mapperObject.readValue(s, mapperObject.getTypeFactory().constructCollectionType(List.class, RankDTO.class));
            System.out.println("inside postexecute=" + rankDTOList.size());

            if (rankDTOList != null || !rankDTOList.isEmpty()) {
                RankDTO user1 = new RankDTO();

                if(id==0) {
                    user1.setRanknumber("Rank");
                    user1.setPlayerName("Name");
                    user1.setCountryName("Country");
                }
                else{
                    user1.setRanknumber("Rank");
                    user1.setPlayerName("Team");
                    user1.setCountryName("Points");

                }

                rankDTOList.add(0, user1);

                ListView listView = (ListView) view.findViewById(R.id.tabList);

                TestBatsmenArrayAdaopter testBatsmenArrayAdaopter = new TestBatsmenArrayAdaopter(view.getContext(), rankDTOList);

                listView.setAdapter(testBatsmenArrayAdaopter);

            }
        } catch (Exception e) {


            e.printStackTrace();
        }

    }

}
