package com.example.sampleandroidapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.LinearLayout;
import android.widget.ListView;

import com.example.sampleandroidapplication.com.dtos.MatchesDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 21-06-2018.
 */

public class MatchFragment extends Fragment {

    View v;
    static int i = 0;
    List<MatchesDTO> matchesDTOList = new ArrayList<>();
    SharedPreferences settings;
    LinearLayout linearLayout;
    ProgressMatchsArrayAdapter progressMatchsArrayAdapter;
    ListView listView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.matchs, null);
        settings = getActivity().getSharedPreferences("MY_PREFS_NAME", 0);
        listView = (ListView)v.findViewById(R.id.current_match_list);
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

        String url=getString(R.string.ip_address).concat(getString(R.string.pdata).concat("Y"));
        linearLayout=(LinearLayout)v.findViewById(R.id.emptydata);
        linearLayout.setVisibility(View.GONE);
        Log.i("url",url);
        try {
            matchesDTOList=new InvokeWebServiceBannerHomePage(v, getActivity()).execute(url).get();
            if(matchesDTOList !=null && !matchesDTOList.isEmpty()){
                progressMatchsArrayAdapter=new ProgressMatchsArrayAdapter(v.getContext(),matchesDTOList);
                listView.setVisibility(View.VISIBLE);
                listView.setAdapter(progressMatchsArrayAdapter);

                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {


                        FragmentManager fragmentManager = getFragmentManager();
                        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                        ResultMatchFragment resultMatchFragment = new ResultMatchFragment();
                        Bundle bundle = new Bundle();
                        bundle.putString("matchId", matchesDTOList.get(position).getMatcheid());
                        resultMatchFragment.setArguments(bundle);
                        fragmentTransaction.replace(R.id.fragment_container, resultMatchFragment);
                        fragmentTransaction.addToBackStack(null);
                        fragmentTransaction.commit();
                    }
                });

            }
            else{
                listView.setVisibility(View.GONE);
                linearLayout.setVisibility(View.VISIBLE);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }

        return v;

    }


    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}


