package com.example.sampleandroidapplication.com.dtos;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.example.sampleandroidapplication.RankingDetails;
import com.example.sampleandroidapplication.RecordBatting;
import com.example.sampleandroidapplication.RecordBowling;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 12-06-2018.
 */

public class RankingfourAdapter extends FragmentStatePagerAdapter
{
    List<String> rankingTabName=new ArrayList<>();
    public RankingfourAdapter(FragmentManager fm, List<String> rankingTabName){

        super(fm);
        this.rankingTabName=rankingTabName;
    }
    @Override
    public Fragment getItem(int position) {
        Bundle bundle=new Bundle();
        int value=0;
        if(rankingTabName.get(position).equalsIgnoreCase("Batsmen")){

             value=1;
        }

        else if(rankingTabName.get(position).equalsIgnoreCase("Bowler")){

            value=2;
        }
        else if(rankingTabName.get(position).equalsIgnoreCase("AllRounder")){

            value=3;
        }
        else{
           value=4;
        }
        bundle.putInt("value",value);
        RankingDetails tab1=new RankingDetails();
        tab1.setArguments(bundle);

        return  tab1;
    }

    @Override
    public int getCount() {
        return rankingTabName.size();
    }

    @Override
    public CharSequence getPageTitle(int position) {
        // Generate title based on item position
        if (rankingTabName != null) {
            return rankingTabName.get(position);
        }
        return null;
    }

}
