package com.example.sampleandroidapplication;

/**
 * Created by Ashwini.R on 07-06-2018.
 */

public class LoginCheck {

    public static final String Login_check="checklogin";
}
