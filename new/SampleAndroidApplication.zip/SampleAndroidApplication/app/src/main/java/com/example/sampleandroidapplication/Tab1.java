package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 30-05-2018.
 */

public class Tab1 extends Fragment {

ListViewAdapter listViewAdapter;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        //Returning the layout file after inflating
        //Change R.layout.tab1 in you classes
        View v= inflater.inflate(R.layout.tab1, container, false);

        List<User> userList= new ArrayList<>();
        User user=new User();
        user.setName("ash");
        user.setMatchName("first");
        user.setMatchName1("Second");
        user.setScore("22");
        user.setScore1("22");
        userList.add(user);
        userList.add(user);

        listViewAdapter=new ListViewAdapter(v.getContext(),userList);

        ListView listView = (ListView)v.findViewById(R.id.tabList);
        listView.setAdapter(listViewAdapter);

        return v;
    }
}
