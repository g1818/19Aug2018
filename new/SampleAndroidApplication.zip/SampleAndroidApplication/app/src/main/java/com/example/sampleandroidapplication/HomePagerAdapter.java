package com.example.sampleandroidapplication;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.util.SparseArray;

import com.example.sampleandroidapplication.com.dtos.MatchesDTO;
import com.example.sampleandroidapplication.com.dtos.SeriesDTO;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Ashwini.R on 14-06-2018.
 */

public class HomePagerAdapter extends FragmentStatePagerAdapter {
    List<MatchesDTO> menus = new ArrayList<>();
    SparseArray<Fragment> registeredFragments = new SparseArray<Fragment>();


    public HomePagerAdapter(FragmentManager fm, List<MatchesDTO> men) {
        super(fm);
        menus = men;

    }

    @Override
    public int getCount() {
        if (menus != null) {
            return menus.size();
        }
        return 0;
    }


    @Override
    public Fragment getItem(int position) {
        Bundle arguments = new Bundle();
        arguments.putSerializable("menus", menus.get(position));
        arguments.putInt("position",position);
        HomePageFragment fragment = new HomePageFragment();
        fragment.setArguments(arguments);
        return fragment;
    }

}