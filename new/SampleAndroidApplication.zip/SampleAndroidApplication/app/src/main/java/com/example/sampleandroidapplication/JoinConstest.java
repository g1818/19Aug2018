package com.example.sampleandroidapplication;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Parcelable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.anton46.stepsview.StepsView;
import com.example.sampleandroidapplication.com.dtos.ContestDTO;
import com.example.sampleandroidapplication.com.dtos.QuestionAnswerPayment;
import com.example.sampleandroidapplication.com.dtos.QuestionsDTO;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * Created by Ashwini.R on 21-06-2018.
 */

public class JoinConstest extends Fragment {

    View v;
    AppCompatButton next;
    TextView textView;
    String matchId;
    Handler mHandler;
    List<QuestionAnswerPayment> questionAnswerPaymentList;
    String url;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.contest, null);
        Toolbar toolbar = v.findViewById(R.id.toolbar);
        Bundle args = getArguments();
         questionAnswerPaymentList = args.getParcelableArrayList("questionList");
        matchId=args.getString("machId");
        textView=(TextView)v.findViewById(R.id.heading);
        textView.setText("Join Contest");
        toolbar.setNavigationIcon(R.drawable.ic_back_button);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
/*        ViewPager pager = (ViewPager)v.findViewById(R.id.viewPager);
        pager.setAdapter(new StepWisePagerAdapter(getChildFragmentManager()));*/

       //Bind the step indicator to the adapter
        StepsView mStepsView = (StepsView)v. findViewById(R.id.stepsView);
        String[] stepWiseNames =  {"Join Contests","Payment","Final"};

        mStepsView.setLabels(stepWiseNames)
                .setBarColorIndicator(getContext().getResources().getColor(R.color.orange))
                .setProgressColorIndicator(getContext().getResources().getColor(R.color.light_color))
                .setLabelColorIndicator(getContext().getResources().getColor(R.color.light_color))
                .setCompletedPosition(0)
                .drawView();

         url=getString(R.string.ip_address).concat(getString(R.string.getContest).concat(matchId));

        new InvokeWebServiceForJoinConstest(v,getActivity(),questionAnswerPaymentList).execute(url);

       /* mHandler = new Handler();
        new Thread(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub
                while (true) {
                    try {
                        Thread.sleep(10000);
                        mHandler.post(new Runnable() {

                            @Override
                            public void run() {
                                Log.i("url",url);
                                new InvokeWebServiceForJoinConstest(v,getActivity(),questionAnswerPaymentList).execute(url);
                         }
                        });
                    } catch (Exception e) {
                        // TODO: handle exception
                    }
                }
            }
        }).start();*/

        return v;
    }
    @Override
    public void onResume() {
        super.onResume();
        ((AppCompatActivity)getActivity()).getSupportActionBar().hide();
    }
    @Override
    public void onStop() {
        super.onStop();
        ((AppCompatActivity)getActivity()).getSupportActionBar().show();
    }
}

class InvokeWebServiceForJoinConstest extends AsyncTask<String,Void,String> {

    List<QuestionAnswerPayment> questionAnswerPaymentList=new ArrayList<>();
    View view;
    List<ContestDTO> contestDTOList=new ArrayList<>();
    FragmentActivity fragmentActivity;
    InvokeWebServiceForJoinConstest(View v, FragmentActivity fragmentActivity,List<QuestionAnswerPayment> questionAnswerPaymentList) {

        view = v;
        this.fragmentActivity=fragmentActivity;
        this.questionAnswerPaymentList=questionAnswerPaymentList;

    }

    @Override
    protected void onPreExecute() {


    }

    @Override
    protected String doInBackground(String... strings) {

        StringBuffer buffer = new StringBuffer();
        try {
            URL url = new URL(strings[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.connect();
            BufferedReader bf = new BufferedReader(new InputStreamReader(con.getInputStream()));

            String line = "";
            while ((line = bf.readLine()) != null) {
                buffer.append(line);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return buffer.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        try {
            ObjectMapper mapperObject = new ObjectMapper();

            Log.i("res",s);
            contestDTOList = mapperObject.readValue(s, mapperObject.getTypeFactory().constructCollectionType(List.class, ContestDTO.class));
            System.out.println("inside postexecute=" + contestDTOList.size());

            if (contestDTOList != null || !contestDTOList.isEmpty()) {


                ListView listView = (ListView) view.findViewById(R.id.tabList);

                ContestArrayAdapter contestArrayAdapter = new ContestArrayAdapter(view.getContext(), contestDTOList,questionAnswerPaymentList,fragmentActivity);

                listView.setAdapter(contestArrayAdapter);

            }
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

}