/*
package com.example.sampleandroidapplication;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {
    private EditText emailEditText;
    private EditText passEditText;
    TextInputLayout textInputLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        textInputLayout=(TextInputLayout)findViewById(R.id.email);
        emailEditText = (EditText) findViewById(R.id.editText_email);
        passEditText = (EditText) findViewById(R.id.editText_password);
        findViewById(R.id.btn_signup).setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                boolean isValidate=true;
                final String email=emailEditText.getText().toString();
                if (!isValidEmail(email)) {
                    emailEditText.setError("Invalid Email");
                    isValidate=false;
                }
                final String pass = passEditText.getText().toString();
                if (!isValidPassword(pass)) {
                    passEditText.setError("Invalid Password");
                    isValidate=false;
                }
                if(isValidate){

                 String url=getString(R.string.ip_address).concat(getString(R.string.login)).concat(emailEditText.getText().toString()).concat(getString(R.string.inputpassword))
                           .concat(passEditText.getText().toString());
                    new InvokeWebServiceForSignupLogin(getApplicationContext(),LoginActivity.this,2).execute(url);
                  */
/* Intent intent = new Intent(LoginActivity.this, Dashboard.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    intent.putExtra("email","abc");
                    intent.putExtra("name","abc");
                    FragmentManager fragmentManager = LoginActivity.this.getSupportFragmentManager();
                    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                    LoginActivity.this.startActivity(intent);*//*

                }
                else
                {
                    Toast.makeText(LoginActivity.this, "Invalid User", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    // validating email id
    private boolean isValidEmail(String email) {
        String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
        Pattern pattern = Pattern.compile(EMAIL_PATTERN);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    // validating password with retype password
    private boolean isValidPassword(String pass) {
        if (pass != null && pass.length() > 6) {
            return true;
        }
        return false;
    }
}*/
